package JumpingSpider::Query;

=head1 NAME Query

This class is for the Jumping Spider.

For more information on the Jumping Spider see the L<Overview>.

Copyright &copy 1997 Curtis E. Dyreson. All rights reserved.
Please be aware of the L<Licence> and L<Version>.

=head1 DESCRIPTION

The query supports only one kind of query currently.

=head1 METHODS

=head2 query(@contentDecriptions, indexTable, reachableTable)

=over 4

=item * @contentDescriptions

- A list of content descriptions

=item * indexTable

- The index table

=item * reachableTable

- The reachable table

=back

Query takes a list of content descriptions and returns a list of URLs.

=cut

#---------------------------------------------------------------------
sub query {
  my ($contentDescriptions, $indexTable, $reachableTable) = @_;
  my @keywords = @$contentDescriptions;
  my @descriptions = ();

  #
  # Retrieve the nodes that match a particular keyword
  #
  my $keyword;
  my $set;
  foreach $keyword (@keywords) {
    $keyword =~ s/^\s+//;
    $keyword =~ s/\s+$//;
    @words = split(/\s+/, $keyword);
    $set = new IdSetWithCount();
    my $word = shift @words;
    $word =~ tr/A-Z/a-z/;
    my $t = $indexTable->retrieveTuple(new StringCol($word));
    $set = $t->getValueAsIdSetWithCount() if $t;
    foreach (@words) {
      tr/A-Z/a-z/;
      my $t = $indexTable->retrieveTuple(new StringCol($_));
      $set->intersectSelf($t->getValueAsIdSetWithCount()) if $t;
      }
    unshift @descriptions, $set;
    }

  #my $jjj;
  #foreach $jjj ($set->enumerateInSortedOrder()) {
  #  my ($id, $count) = @$jjj;
  #  print $id->toString() . " $count\n";
  #  }

  #
  # Solve for each keyword
  #
  my $firstSet = shift @descriptions;
  my $firstList;
  my $previous;
  
  my $result = new IdSetWithCount();
  my $keep;
  foreach $firstList ($firstSet->enumerateInSortedOrder()) {
    my ($first, $score) = @$firstList;
    $keep = 1;
    my $i;
    my $previousSet = new IdSet();
    $previousSet->insert($first);
    my $intermediate = new IdSet();
    for ($i=0; $i < scalar @descriptions; $i++) {
      $intermediate = new IdSet();
      my $matchedSet = $descriptions[$i];
      foreach $previous ($previousSet->enumerate()) {
        my $t = $reachableTable->retrieveTuple($previous);
        if ($t) {
          my $reachableSet = $t->getValueAsIdSet() || new IdSet();
          $intermediate->unionSelf($reachableSet->intersect($matchedSet));
          }
        }
      if ($intermediate->numberOfElements == 0) { 
        $keep = 0;
        $i = scalar @descriptions; 
        }
      $previousSet = $intermediate;
      }
    if ($keep) { $result->insertWithCount($first,$score); }
    }
  
  #
  # What are the results?
  #
  my $test;
  my @result = ();
  foreach $test ($result->enumerateInSortedOrder()) {
    my ($id, $count) = @$test;
    #push @result, $id->toString() . " $count";
    push @result, $id;
    }

  return \@result;

}
#---------------------------------------------------------------------

1;
