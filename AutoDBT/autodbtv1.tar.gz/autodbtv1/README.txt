This release contains code to run and test AutoDBT. The following files
are included.

Modeling a web application (OCRS) (Prolog rules provided by a modeler).
  dataflow.in - The model of the application.
  update.in - The model of the updates in the application.
  graph.in - A graph of the transitions in the application model.
  dbStandard.P - Standard DB update predicates
  db.P - Rules to update AD and SD predicates

Testing the application (Perl code)
  runTests - Code to run an entire test of the AutoDBT
  factsGenerate - Generate the AD and SD (facts.P)
  codeGenerate - Combine update spec and input spec to generate rules
  generate - Generate the guards and oracles
  testit - run a single test
  processResults - code to process the results and spit out graphable numbers

Prolog programs (generated)
  facts.P - A collection of AD and SD facts 
  d.P - The produced model with updates and inputs
  g.P - Generated guards
  j.P - Generated guard evaluation, producins test sequences
  t.P - Code to produce the test sequences
  guard.in - Transtions to test 
