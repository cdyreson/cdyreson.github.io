my $TestSize = @ARGV[0];

open (PROLOG, "| XSB/bin/xsb");
print PROLOG "load_dyn('facts.P').\n";
print PROLOG '[db].' . "\n";
print PROLOG '[dbStandard].' . "\n";
print PROLOG '[d].' . "\n";
print PROLOG '[t].' . "\n";
print PROLOG '[g].' . "\n";
print PROLOG '[j].' . "\n";
my $i = 1;
#for ($i = 1; $i < 8; $i++) {
#  print PROLOG "f$i.\n";
#  }

for ($i = 1; $i <= $TestSize; $i++) {
  print PROLOG "test$i.\n";
  }

close PROLOG;
