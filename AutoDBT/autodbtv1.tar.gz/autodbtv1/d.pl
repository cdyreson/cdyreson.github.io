input1(A1, A1, S1, S1) :-
     button(make).

input10(C_10, A1, A3, S1, S1) :-
     ad_reservation(C_10, X, Y, Z, A1),
     button(back),
     ad_reservation(C_10, Pd_10_2, Rd_10_2, Ct_10_2, A1),
     delete_ad(ad_reservation(C_10, Pd_10_2, Rd_10_2, Ct_10_2), A1, A2),
     ad_reserves(Cid_10_3, C_10, A2),
     delete_ad(ad_reserves(Cid_10_3, C_10), A2, A3).

input11(A1, A1, S1, S1) :-
     button(cancel).

input12(A1, A1, S1, S1) :-
     button(back).

input14(Pd_14, Rd_14, Ct_14, A1, A2, S1, S2) :-
     sd_reservation(X, Pd_14, Rd_14, Ct_14, S1),
     delete_sd(sd_reservation(X, Pd_14, Rd_14, Ct_14), S1, S2),
     button(confirm),
     insert_ad(ad_reservation(X_14_4, Pd_14, Rd_14, Ct_14), A1, A2).

input15(A1, A1, S1, S1) :-
     button(back).

input16(A1, A1, S1, S1) :-
     ad_reservation(C, X, Y, Z, A1),
     button(continue).

input17(C_17, A1, A1, S1, S1) :-
     ad_reservation(C_17, Pd, Rd, Ct, A1),
     button(back).

input18(A1, A1, S1, S1) :-
     button(view).

input2(A1, A1, S1, S1) :-
     button(modify).

input3(Fn_3, Ln_3, C_3, A1, A1, S1, S1) :-
     ad_customer(Fn_3, Ln_3, Cid, A1),
     ad_reserves(Cid, C_3, A1),
     button(cancel).

input31(Fn_31, Ln_31, C_31, A1, A1, S1, S1) :-
     sd_customer(Fn_31, Ln_31, Cid, S1),
     sd_reserves(Cid, C_31, S1),
     button(cancel).

input4(Fn_4, Ln_4, C_4, A1, A1, S1, S1) :-
     ad_customer(Fn_4, Ln_4, Cid, A1),
     ad_reserves(Cid, C_4, A1),
     button(continue).

input5(Pd_5, Rd_5, Ct_5, A1, A1, S1, S1) :-
     sd_reservation(X, Pd_5, Rd_5, Ct_5, S1),
     button(cancel).

input51(Pd_51, Rd_51, Ct_51, A1, A1, S1, S1) :-
     ad_reservation(X, Pd_51, Rd_51, Ct_51, A1),
     button(cancel).

input6(Pd_6, Rd_6, Ct_6, C, C, A1, A3, S1, S2) :-
     sd_reservation(X, Pd_6, Rd_6, Ct_6, S1),
     delete_sd(sd_reservation(X, Pd_6, Rd_6, Ct_6), S1, S2),
     button(continue),
     ad_reservation(C, Pd2_6_5, Rd2_6_5, Ct2_6_5, A1),
     delete_ad(ad_reservation(C, Pd2_6_5, Rd2_6_5, Ct2_6_5), A1, A2),
     insert_ad(ad_reservation(C, Pd_6, Rd_6, Ct_6), A2, A3).

input7(A1, A1, S1, S1) :-
     button(back).

input8(A1, A1, S1, S1) :-
     button(cancel).

input9(C_9, A1, A1, S1, S1) :-
     ad_reservation(C_9, X, Y, Z, A1),
     button(back).

input91(C_91, A1, A1, S1, S1) :-
     sd_reservation(C_91, X, Y, Z, S1),
     button(back).
