#!/coll/local/bin/perl -I. -ISemiStructured/lib -I/user/curtis/perl/BerkeleyDB-0.04 -I/user/curtis/perl/BerkeleyDB-0.04/blib/arch -I/user/curtis/perl/BerkeleyDB-0.04/blib/lib";
 
#
# This is the WWW interface script!!!
#
# Copyright (c) 1998. Curtis E. Dyreson. All rights reserved.  
# yeah, blah blah standard disclaimer follows
# This software is covered under the general license and lack of 
# warranty as stated in the installation kit. WARNING! DANGER WILL 
# ROBINSON! USE AT YOUR OWN RISK!  
 
use strict;
use CGI_Lite;
use SemiStructuredDB;
use FileHandle;
use IPC::Open2;

my $cgi = new CGI_Lite;
 
my $ROOT = 'http://www.cs.auc.dk/~curtis/cgi-bin';
my $LESSONROOT = 'http://www.cs.auc.dk/~curtis/AUCQL/';
my $tail =<<'TAIL';
  AUCQL  <a href="../AUCQL/">home</a> | 
         <a href="../AUCQL/doc.html">documentation</a> |
         <a href="../AUCQL/examples.html">examples</a> 
TAIL

# Build the header
 print "Content-type: text/html", "\r\n\r\n";
 my $data = $cgi->parse_form_data();
 my ($tailVar) = '';
 
 if (defined $$data{'tail'}) {
   $tail = '<a href="' . $LESSONROOT . $$data{'tail'} 
           . '">Return to Example</a>';
   $tailVar = '<INPUT TYPE="hidden" NAME="tail" VALUE="' . $$data{'tail'}. '">';
   }
 if (defined $$data{'query'}) { &query($data); }
 else { &starter(); }

sub starter {
  print "<HTML>";
  print  <<"HEAD";
  <HEAD>
  <TITLE>
  AUCQL - Aalborg University Semi-structured with Properties Query Engine
  </TITLE>
  </HEAD>
  <BODY>
  <h1> AUCQL query engine </h1>
  <hr>
  <FORM METHOD="POST" ACTION="$ROOT/starter.pl">
  Enter an AUCQL query below.<BR>
  <TEXTAREA NAME="query" ROWS=5 COLS=80>
SELECT *
FROM ()+ AllNodes,
     DIMENSION(NAME, AllNodes) AllPaths;
  </TEXTAREA>
  <BR>$tailVar
  <INPUT TYPE="submit" NAME="submit" VALUE="submit">
  </FORM>
  <P>
  <hr>
  </BODY>
$tail
  </HTML>
HEAD
}

sub query {
  my ($data) = @_;

  my ($query) = $$data{'query'};
  my ($pid) = $$;
  my ($fileName) = "/user/curtis/AUCQL";
  my ($OPTIONS) = "-verbose -databaseName SemiStructured/dbs -databaseMode BerkeleyDB";
  my ($perl) = "perl -ISemiStructured/lib -ISemiStructured/YAPP/yapp/Parse-Yapp-0.15 -I/user/curtis/perl/BerkeleyDB-0.04 -I/user/curtis/perl/BerkeleyDB-0.04/blib/arch -I/user/curtis/perl/BerkeleyDB-0.04/blib/lib";

  # Added for pipe IO
  $| = 1;
  my ($parser) = "$perl SemiStructured/bin/evaluateQuery $OPTIONS";
  my $pid = open2( \*Reader, \*Writer, $parser );
  #Writer->autoflush(); 
  print Writer $query;
  close Writer;
  my @lines = <Reader>;
  close Reader;

  print "<HTML>";
  print  <<"HEAD";
  <HEAD>
  <TITLE>
  AUCQL - Aalborg University Semi-structured with Properties Query Engine
  </TITLE>
  </HEAD>
  <BODY>
  <h1> AUCQL query engine </h1>
  <hr>
  <FORM METHOD="POST" ACTION="$ROOT/starter.pl">
  Enter an AUCQL query below.<BR>
  <TEXTAREA NAME="query" ROWS=5 COLS=80>
$query
  </TEXTAREA>
  <BR>$tailVar
  <INPUT TYPE="submit" NAME="submit" VALUE="submit">
  </FORM>
  <P>
  <hr>
@lines
  <hr>
  </BODY>
$tail
  </HTML>
HEAD
}

