#########################################################################
#
#      This file was generated using Parse::Yapp version 0.15.
#
#          Don't edit this file, use source file instead.
#
#               ANY CHANGE MADE HERE WILL BE LOST !
#
#########################################################################
package Parser::LoadDB;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );

use Parse::Yapp::Driver;


require 5.004;

use Carp;
use OODatabase;



sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '0.15',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			"insert" => 2,
			"add" => 5
		},
		DEFAULT => -2,
		GOTOS => {
			'statementList' => 1,
			'statement' => 3,
			'start' => 4
		}
	},
	{#State 1
		DEFAULT => -1
	},
	{#State 2
		ACTIONS => {
			"edge" => 7
		},
		GOTOS => {
			'insertStatement' => 6
		}
	},
	{#State 3
		ACTIONS => {
			"insert" => 2,
			"add" => 5
		},
		DEFAULT => -2,
		GOTOS => {
			'statementList' => 8,
			'statement' => 3
		}
	},
	{#State 4
		ACTIONS => {
			'' => 9
		}
	},
	{#State 5
		ACTIONS => {
			"dimension" => 10
		},
		GOTOS => {
			'addStatement' => 11
		}
	},
	{#State 6
		ACTIONS => {
			"semi-colon" => 12
		}
	},
	{#State 7
		DEFAULT => -8,
		GOTOS => {
			'@2-1' => 13
		}
	},
	{#State 8
		DEFAULT => -3
	},
	{#State 9
		DEFAULT => -0
	},
	{#State 10
		ACTIONS => {
			"identifier" => 14
		}
	},
	{#State 11
		ACTIONS => {
			"semi-colon" => 15
		}
	},
	{#State 12
		DEFAULT => -5
	},
	{#State 13
		ACTIONS => {
			"identifier" => 16,
			"timeInterval" => 17,
			"integer" => 18,
			"object" => 21,
			"string" => 19
		},
		GOTOS => {
			'literal' => 20,
			'node' => 22
		}
	},
	{#State 14
		ACTIONS => {
			"left parenthesis" => 23
		}
	},
	{#State 15
		DEFAULT => -4
	},
	{#State 16
		DEFAULT => -27
	},
	{#State 17
		DEFAULT => -28
	},
	{#State 18
		DEFAULT => -29
	},
	{#State 19
		DEFAULT => -30
	},
	{#State 20
		DEFAULT => -26
	},
	{#State 21
		DEFAULT => -25
	},
	{#State 22
		ACTIONS => {
			"comma" => 24
		}
	},
	{#State 23
		ACTIONS => {
			"identifier" => 25
		}
	},
	{#State 24
		DEFAULT => -9,
		GOTOS => {
			'@3-4' => 26
		}
	},
	{#State 25
		DEFAULT => -6,
		GOTOS => {
			'@1-4' => 27
		}
	},
	{#State 26
		ACTIONS => {
			"identifier" => 16,
			"timeInterval" => 17,
			"integer" => 18,
			"object" => 21,
			"string" => 19
		},
		GOTOS => {
			'literal' => 20,
			'node' => 28
		}
	},
	{#State 27
		ACTIONS => {
			"right parenthesis" => 29
		}
	},
	{#State 28
		DEFAULT => -10,
		GOTOS => {
			'@4-6' => 30
		}
	},
	{#State 29
		DEFAULT => -7
	},
	{#State 30
		ACTIONS => {
			"left parenthesis" => 33
		},
		DEFAULT => -12,
		GOTOS => {
			'propertyList' => 31,
			'properties' => 32
		}
	},
	{#State 31
		DEFAULT => -13
	},
	{#State 32
		DEFAULT => -11
	},
	{#State 33
		ACTIONS => {
			"identifier" => 34
		},
		GOTOS => {
			'property' => 35
		}
	},
	{#State 34
		DEFAULT => -17,
		GOTOS => {
			'@5-1' => 36
		}
	},
	{#State 35
		ACTIONS => {
			"comma" => 38
		},
		DEFAULT => -15,
		GOTOS => {
			'propertyListContinues' => 37
		}
	},
	{#State 36
		ACTIONS => {
			"colon" => 39,
			"exclamation mark" => 42
		},
		GOTOS => {
			'optionalProperty' => 40,
			'propertyContinues' => 41,
			'requiredProperty' => 43
		}
	},
	{#State 37
		ACTIONS => {
			"right parenthesis" => 44
		}
	},
	{#State 38
		ACTIONS => {
			"identifier" => 34
		},
		GOTOS => {
			'property' => 45
		}
	},
	{#State 39
		DEFAULT => -23,
		GOTOS => {
			'@7-1' => 46
		}
	},
	{#State 40
		DEFAULT => -20
	},
	{#State 41
		DEFAULT => -18
	},
	{#State 42
		DEFAULT => -21,
		GOTOS => {
			'@6-1' => 47
		}
	},
	{#State 43
		DEFAULT => -19
	},
	{#State 44
		DEFAULT => -14
	},
	{#State 45
		ACTIONS => {
			"comma" => 38
		},
		DEFAULT => -15,
		GOTOS => {
			'propertyListContinues' => 48
		}
	},
	{#State 46
		ACTIONS => {
			"identifier" => 16,
			"timeInterval" => 17,
			"integer" => 18,
			"string" => 19
		},
		GOTOS => {
			'literal' => 49
		}
	},
	{#State 47
		ACTIONS => {
			"identifier" => 16,
			"timeInterval" => 17,
			"integer" => 18,
			"string" => 19
		},
		GOTOS => {
			'literal' => 50
		}
	},
	{#State 48
		DEFAULT => -16
	},
	{#State 49
		DEFAULT => -24
	},
	{#State 50
		DEFAULT => -22
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'start', 1, undef
	],
	[#Rule 2
		 'statementList', 0, undef
	],
	[#Rule 3
		 'statementList', 2, undef
	],
	[#Rule 4
		 'statement', 3, undef
	],
	[#Rule 5
		 'statement', 3, undef
	],
	[#Rule 6
		 '@1-4', 0,
sub {
 &_expecting("domain of dimension $_[2]"); 
       print "Adding dimension $_[2]\n";
       $Global::SSGraph->addDimension({$_[2]}, $_[4]);
       
}
	],
	[#Rule 7
		 'addStatement', 6, undef
	],
	[#Rule 8
		 '@2-1', 0,
sub {
 &_expecting("a from object to insert"); 
}
	],
	[#Rule 9
		 '@3-4', 0,
sub {
 &_expecting("a to object to insert"); 
}
	],
	[#Rule 10
		 '@4-6', 0,
sub {
 &_expecting("a property list"); 
}
	],
	[#Rule 11
		 'insertStatement', 8,
sub {
$Global::SSGraph->addEdge(
        new Edge(new Node($_[3]), 
                new Label([new Region($_[8])]),
                new Node($_[6])
               )
        );
    print "Inserting edge from $_[3] to $_[6]\n";
    
}
	],
	[#Rule 12
		 'properties', 0,
sub {
 my %h = (); return \%h; 
}
	],
	[#Rule 13
		 'properties', 1,
sub {
 return $_[1]; 
}
	],
	[#Rule 14
		 'propertyList', 4,
sub {
 my $h = $_[3]; 
      my ($d, $pair) = @{$_[2]}; 
      my ($v, $w) = @$pair;
      print "list is $d, $w, $v\n";
      my ($value) = Dimensions::convert($d,$v); 
      $value->required() if $w eq 'required';
      $$h{$d} = $value;
      return $h; 
}
	],
	[#Rule 15
		 'propertyListContinues', 0,
sub {
 my %h = (); return \%h; 
}
	],
	[#Rule 16
		 'propertyListContinues', 3,
sub {
 my $h = $_[3]; 
      my ($d, $pair) = @{$_[2]}; 
      my ($v, $w) = @$pair;
      print "list is $d, $w, $v\n";
      my ($value) = Dimensions::convert($d,$v); 
      $value->required() if $w eq 'required';
      $$h{$d} = $value;
      return $h; 
}
	],
	[#Rule 17
		 '@5-1', 0,
sub {
 &_expecting("a property dimension name"); 
}
	],
	[#Rule 18
		 'property', 3,
sub {
 return [lc $_[1], $_[3]]; 
}
	],
	[#Rule 19
		 'propertyContinues', 1,
sub {
 return $_[1]; 
}
	],
	[#Rule 20
		 'propertyContinues', 1,
sub {
 return $_[1]; 
}
	],
	[#Rule 21
		 '@6-1', 0,
sub {
 &_expecting("an exclamation mark"); 
}
	],
	[#Rule 22
		 'requiredProperty', 3,
sub {
 &_expecting("a property dimension value"); 
      return [$_[3], 'required']; 
}
	],
	[#Rule 23
		 '@7-1', 0,
sub {
 &_expecting("a colon"); 
}
	],
	[#Rule 24
		 'optionalProperty', 3,
sub {
 &_expecting("a property dimension value"); 
      return [$_[3], 'optional']; 
}
	],
	[#Rule 25
		 'node', 1,
sub {
 return $_[1]; 
}
	],
	[#Rule 26
		 'node', 1,
sub {
 return $_[1]; 
}
	],
	[#Rule 27
		 'literal', 1,
sub {
 return $_[1]; 
}
	],
	[#Rule 28
		 'literal', 1,
sub {
 return $_[1]; 
}
	],
	[#Rule 29
		 'literal', 1,
sub {
 return $_[1]; 
}
	],
	[#Rule 30
		 'literal', 1,
sub {
 return $_[1]; 
}
	]
],
                                  @_);
    bless($self,$class);
}



my $ErrorMessage = '';
my $toHere = '';
sub _Error {
 my ($parser) = shift;

 print "<PRE>\n";
 print $toHere;
 print " <--- Syntax error.\n";
 print "------------------------------------------------------\n";
 print " Perhaps the problem is: $ErrorMessage.\n";
 print "------------------------------------------------------\n";
 $parser->_dumpRest();
 print "</PRE>\n";
 exit(1);
}

# cleans the white space from around a string
sub _cleanWS {
  my ($value) = @_;
  #chew up white space at both ends (parsing of fields depends on this!)
  $value =~ s/^[\s\n]+//;
  $value =~ s/[\s\n]+$//;
  return $value;
}

sub _dumpRest {
    my($parser)=shift;

    my $thing;
    foreach $thing (@{$parser->{'tokens'}}) {
      print @$thing[2] if defined @$thing[1];
    }
}

sub _Lexer {
    my ($parser) = shift;

    #die "end of inputer" unless scalar @{$parser->{'tokens'}};
    return ['', undef, undef] unless scalar @{$parser->{'tokens'}};
    #print "_lexer " . @{@{$parser->{'tokens'}}[0]}[1] . "\n";
    my $token = shift @{$parser->{'tokens'}};
    $toHere .= @$token[2] if defined @$token[2];
    return @{ $token };
}

sub Run {
    my($self)=shift;

    $self->_tokenize();
    $self->YYParse( yylex => \&_Lexer, yyerror => \&_Error );

}

sub _tokenize {
  my ($self) = shift;

  my @tokens = ();
  my @lines = <STDIN>;
  my $s = '';
  foreach (@lines) { $s .= $_ unless /^\s*\;/; }
  my %keywords = ( 
     'insert' => 'insert', 
     'add' => 'add', 
     'edge' => 'edge', 
     'dimension' => 'dimension',
     'any' => 'any',
     'root' => 'root',
     );

  # gobble white space
  $s =~ s/^\s*//;
  my $originalText = $&;
  while ($s) {
    #print $s;
    my %token = ();
    $token{'kind'} =  'ignore';

    if ($s =~ s/^'([^']*)'//) {
      $token{'kind'} =  'string';
      $token{'text'} =  $1;
      }
    elsif ($s =~ s/^\[(\w+(\/\w+\/\d+)?\s*-\s*\w+(\/\w+\/\d+)?)\s*\]//) {
      $token{'kind'} =  'timeInterval';
      $token{'text'} =  _cleanWS($1);
      }
    elsif ($s =~ s/^(\d+)\s*//) {
      $token{'kind'} =  'integer';
      $token{'text'} =  _cleanWS($1);
      }
    elsif ($s =~ s/^(\.)//) {
      $token{'kind'} =  'period';
      $token{'text'} =  $1;
      }
    elsif ($s =~ s/^(\Q,\E)//) {
      $token{'kind'} =  'comma';
      $token{'text'} =  $1;
      }
    elsif ($s =~ s/^(\Q:\E)//) {
      $token{'kind'} =  'colon';
      $token{'text'} =  $1;
      }
    elsif ($s =~ s/^(\Q!\E)//) {
      $token{'kind'} =  'exclamation mark';
      $token{'text'} =  $1;
      }
    elsif ($s =~ s/^(\Q;\E)//) {
      $token{'kind'} =  'semi-colon';
      $token{'text'} =  $1;
      }
    elsif ($s =~ s/(^\))//) {
      $token{'kind'} =  'right parenthesis';
      $token{'text'} =  $1;
      }
    elsif ($s =~ s/^(\()//) {
      $token{'kind'} =  'left parenthesis';
      $token{'text'} =  $1;
      }
    elsif ($s =~ s/^(\Q<>\E)//) {
      $token{'kind'} =  'comparison';
      $token{'text'} =  $1;
      }
    elsif ($s =~ s/^([=><]+)//) {
      $token{'kind'} =  'comparison';
      $token{'text'} =  $1;
      }
    elsif ($s =~ s/^\Q&\E([A-Za-z0-9_]*)//) {
      $token{'kind'} =  'object';
      $token{'text'} =  _cleanWS('&'.$1);
      }
    elsif ($s =~ s/^([A-Za-z][A-Za-z0-9_]*)//) {
      $token{'text'} =  _cleanWS($1);
      if (defined $keywords{lc $1}) {
        $token{'kind'} =  $keywords{lc $1};
        }
      else {
        $token{'kind'} =  'identifier';
        }
      }
    elsif ($s =~ s/(.)//) {
      $token{'kind'} =  'ignore';
      $token{'text'} =  $1;
      }
    else {
      die "can't possibly reach here";
      }
    $token{'originalText'} = "$originalText$&";
    push @tokens, [$token{'kind'}, $token{'text'}, $token{'originalText'}];
    #print "token $token{'kind'} $token{'text'} $token{'originalText'}\n";
    #print "token $token{'kind'} $token{'text'}\n";
    # gobble white space
    $s =~ s/^\s*//;
    $originalText = $&;
    }
  push @tokens, ['', undef, undef];
  $self->{'tokens'} = \@tokens;
}

sub _expecting {
  my ($s) = @_;
  $ErrorMessage = "Expecting $s";
  }

1;
