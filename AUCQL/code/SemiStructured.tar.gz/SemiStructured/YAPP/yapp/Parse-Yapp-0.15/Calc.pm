#########################################################################
#
#      This file was generated using Parse::Yapp version 0.15.
#
#          Don't edit this file, use source file instead.
#
#               ANY CHANGE MADE HERE WILL BE LOST !
#
#########################################################################
package Calc;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );

use Parse::Yapp::Driver;



sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '0.15',
                                  yystates =>
[
	{#State 0
		DEFAULT => -1,
		GOTOS => {
			'input' => 1
		}
	},
	{#State 1
		ACTIONS => {
			"\n" => 6,
			'' => 3,
			'NUM' => 2,
			'VAR' => 7,
			'error' => 8,
			"-" => 9,
			"(" => 4
		},
		GOTOS => {
			'line' => 5,
			'exp' => 10
		}
	},
	{#State 2
		DEFAULT => -6
	},
	{#State 3
		DEFAULT => -0
	},
	{#State 4
		ACTIONS => {
			'NUM' => 2,
			'VAR' => 7,
			"-" => 9,
			"(" => 4
		},
		GOTOS => {
			'exp' => 11
		}
	},
	{#State 5
		DEFAULT => -2
	},
	{#State 6
		DEFAULT => -3
	},
	{#State 7
		ACTIONS => {
			"=" => 12
		},
		DEFAULT => -7
	},
	{#State 8
		ACTIONS => {
			"\n" => 13
		}
	},
	{#State 9
		ACTIONS => {
			'NUM' => 2,
			'VAR' => 7,
			"-" => 9,
			"(" => 4
		},
		GOTOS => {
			'exp' => 14
		}
	},
	{#State 10
		ACTIONS => {
			"\n" => 16,
			"*" => 15,
			"+" => 17,
			"-" => 18,
			"^" => 19,
			"/" => 20
		}
	},
	{#State 11
		ACTIONS => {
			"*" => 15,
			"+" => 17,
			"-" => 18,
			"^" => 19,
			"/" => 20,
			")" => 21
		}
	},
	{#State 12
		ACTIONS => {
			'NUM' => 2,
			'VAR' => 7,
			"-" => 9,
			"(" => 4
		},
		GOTOS => {
			'exp' => 22
		}
	},
	{#State 13
		DEFAULT => -5
	},
	{#State 14
		ACTIONS => {
			"^" => 19
		},
		DEFAULT => -13
	},
	{#State 15
		ACTIONS => {
			'NUM' => 2,
			'VAR' => 7,
			"-" => 9,
			"(" => 4
		},
		GOTOS => {
			'exp' => 23
		}
	},
	{#State 16
		DEFAULT => -4
	},
	{#State 17
		ACTIONS => {
			'NUM' => 2,
			'VAR' => 7,
			"-" => 9,
			"(" => 4
		},
		GOTOS => {
			'exp' => 24
		}
	},
	{#State 18
		ACTIONS => {
			'NUM' => 2,
			'VAR' => 7,
			"-" => 9,
			"(" => 4
		},
		GOTOS => {
			'exp' => 25
		}
	},
	{#State 19
		ACTIONS => {
			'NUM' => 2,
			'VAR' => 7,
			"-" => 9,
			"(" => 4
		},
		GOTOS => {
			'exp' => 26
		}
	},
	{#State 20
		ACTIONS => {
			'NUM' => 2,
			'VAR' => 7,
			"-" => 9,
			"(" => 4
		},
		GOTOS => {
			'exp' => 27
		}
	},
	{#State 21
		DEFAULT => -15
	},
	{#State 22
		ACTIONS => {
			"*" => 15,
			"+" => 17,
			"-" => 18,
			"^" => 19,
			"/" => 20
		},
		DEFAULT => -8
	},
	{#State 23
		ACTIONS => {
			"^" => 19
		},
		DEFAULT => -11
	},
	{#State 24
		ACTIONS => {
			"*" => 15,
			"^" => 19,
			"/" => 20
		},
		DEFAULT => -9
	},
	{#State 25
		ACTIONS => {
			"*" => 15,
			"^" => 19,
			"/" => 20
		},
		DEFAULT => -10
	},
	{#State 26
		ACTIONS => {
			"^" => 19
		},
		DEFAULT => -14
	},
	{#State 27
		ACTIONS => {
			"^" => 19
		},
		DEFAULT => -12
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'input', 0, undef
	],
	[#Rule 2
		 'input', 2,
sub {
 push(@{$_[1]},$_[2]); $_[1] 
}
	],
	[#Rule 3
		 'line', 1,
sub {
 $_[1] 
}
	],
	[#Rule 4
		 'line', 2,
sub {
 print "$_[1]\n" 
}
	],
	[#Rule 5
		 'line', 2,
sub {
 $_[0]->YYErrok 
}
	],
	[#Rule 6
		 'exp', 1, undef
	],
	[#Rule 7
		 'exp', 1,
sub {
 $_[0]->YYData->{VARS}{$_[1]} 
}
	],
	[#Rule 8
		 'exp', 3,
sub {
 $_[0]->YYData->{VARS}{$_[1]}=$_[3] 
}
	],
	[#Rule 9
		 'exp', 3,
sub {
 $_[1] + $_[3] 
}
	],
	[#Rule 10
		 'exp', 3,
sub {
 $_[1] - $_[3] 
}
	],
	[#Rule 11
		 'exp', 3,
sub {
 $_[1] * $_[3] 
}
	],
	[#Rule 12
		 'exp', 3,
sub {

                                      $_[3]
                                  and return($_[1] / $_[3]);
                                  $_[0]->YYData->{ERRMSG}
                                    =   "Illegal division by zero.\n";
                                  $_[0]->YYError;
                                  undef
                                
}
	],
	[#Rule 13
		 'exp', 2,
sub {
 -$_[2] 
}
	],
	[#Rule 14
		 'exp', 3,
sub {
 $_[1] ** $_[3] 
}
	],
	[#Rule 15
		 'exp', 3,
sub {
 $_[2] 
}
	]
],
                                  @_);
    bless($self,$class);
}



sub _Error {
        exists $_[0]->YYData->{ERRMSG}
    and do {
        print $_[0]->YYData->{ERRMSG};
        delete $_[0]->YYData->{ERRMSG};
        return;
    };
    print "Syntax error.\n";
}

sub _Lexer {
    my($parser)=shift;

        $parser->YYData->{INPUT}
    or  $parser->YYData->{INPUT} = <STDIN>
    or  return('',undef);

    $parser->YYData->{INPUT}=~s/^[ \t]//;

    for ($parser->YYData->{INPUT}) {
        s/^([0-9]+(?:\.[0-9]+)?)//
                and return('NUM',$1);
        s/^([A-Za-z][A-Za-z0-9_]*)//
                and return('VAR',$1);
        s/^(.)//s
                and return($1,$1);
    }
}

sub Run {
    my($self)=shift;
    $self->YYParse( yylex => \&_Lexer, yyerror => \&_Error );
}

my($calc)=new Calc;
$calc->Run;

1;
