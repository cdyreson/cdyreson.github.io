#!/usr/local/bin/perl

require 5.004; # or use CLex.pl
use Parse::Lex;

$lexer = Parse::Lex->new(
         qw(
             ADDOP    [-+]
             LEFTP    [\(]
             RIGHTP   [\)]
             INTEGER  [1-9][0-9]*
             NEWLINE  \n
            ),
          qw(STRING),   [qw(" (?:[^"]+|"")* ")],
          qw(ERROR  .*), sub {
            die qq!can\'t analyze: "$_[1]"\n!;
          }
   );


$lexer->from(\*STDIN);

$lexer->every (sub { 
		 my $self = shift;
		 print $self->name, "\t";
		 print $self->text, "\n";
	       });
