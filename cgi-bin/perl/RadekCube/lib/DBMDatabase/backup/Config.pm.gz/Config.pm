package Config;

=head1 NAME Config.pm

This class includes all the things required for the Configuration of
a simple (non-concurrent) database based on DBM files.  You must
edit this file to set which kind of DBM file you want to use.

=head1 DESCRIPTION

It has several parts 

=over 4

=item * 

L<database::Database> 
- The database itself.

=item * 

L<database::Table> 
- A table in the database. All tables have two columns.

=item * 

L<database::Tuple> 
- A tuple in a table. All tuples have a key and a value.

=item * 

L<database::Id> 
- An allowed column data-type.  An Id is the internal representation
of a string (as a list of integers).  An Id can be a key.

=item * 

L<database::IdList> 
- An allowed column data-type.  An list of Ids.  An IdList can be a key.

=item * 

L<database::IdSet> 
- An allowed column data-type.  An set of Ids.  An IdSet cannot be a key.

=item * 

L<database::StringCol> 
- An allowed column data-type.  A string.  A StringCol can be a key.

=item * 

L<database::StringList> 
- An allowed column data-type.  A list of string.  A StringList can be a key.

=item * 

L<database::Convert> 
- An internal class to implement the automatic conversion between strings 
and ids.  It is effectively a private class for the database.

=back 

Copyright &copy 1997 Curtis E. Dyreson. All rights reserved.

=cut

require database::Id;
require database::Convert;
require database::IdList;
require database::IdSet;
require database::IdSetWithCount;
require database::StringCol;
require database::StringList;
require database::Tuple;
require database::Table;
require database::Database;

print "loaded\n";

1;
