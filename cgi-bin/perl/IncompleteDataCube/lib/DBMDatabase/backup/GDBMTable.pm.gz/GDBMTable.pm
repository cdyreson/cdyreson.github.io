package Table;

BEGIN { @AnyDBM_File::ISA = qw(DB_File GDBM_File NDBM_File) }
use AnyDBM_File;
use GDBM_File;

=head1 NAME Table

This package is part of L<database>.
For more information on the database see the L<database::Overview>.

Copyright &copy 1997 Curtis E. Dyreson. All rights reserved.
Please be aware of the L<database::Licence> and L<database::Version>.

=head1 DESCRIPTION

This class represents a table in a L<database::Database>.
A table is a dbm file.  Each entry in the table is
a L<database::Tuple>.  The class has been configured to use GDBM files.

=head1 METHODS

=head2 new(string $tableName)

=over 4

=item * string $tableName 

- The name of the table (a dbm file name).

=back

Create a table with the give name (opens a dbm file).
Second line.

=cut

my $GDBM = 1;
my $BSD = 0;
my $DBM = 0;

#---------------------------------------------------------------------
  sub new {
    my $type = shift;
    my $self = {};
    my ($name) = shift;
    $self->{'class'} = $type;
    $self->{'name'} = $name;
    $self->{'count'} = 0 if $GDBM;
    local (*tempdb);

    tie %tempdb, GDBM_File, $name, (GDBM_WRCREAT + GDBM_REPLACE), 0640 if $GDBM;
    tie %tempdb, "DB_File", $name, O_RDWR|O_CREAT, 0640 if $BSD;
    dbmopen(%tempdb, $name, 0660) if $DBM ;

    $self->{'dbm'} = *tempdb;
    bless $self, $type;
    }
#---------------------------------------------------------------------

=head2 useBSD()

Configure the underlying database as BSD rather than GDBM

=cut

#---------------------------------------------------------------------
  sub useBSD {
    require DB_File ;
    require Fcntl ;
    $BSD = 1;
    $GDBM = 0;
    $DBM = 0;
    }
#---------------------------------------------------------------------

=head2 insertTuple(Tuple $tuple)

=over 4

=item * 

L<database::Tuple> $tuple - The tuple to insert.

=back

Insert a L<database::Tuple> into the table.  Will replace an existing 
tuple so be careful.

=cut

#---------------------------------------------------------------------
  sub insertTuple {
    my ($self, $tuple) = @_;
    my ($key) = $tuple->getKeyAsBytes();
    my ($value) = $tuple->getValueAsBytes();

    local (*dbm) = $self->{'dbm'};

    $dbm{$key} = $value;

    if ($GDBM) {
      my ($count) = $self->{'count'};
      $count++;
      #reorganize every 5000th insert 
      if ($count >= 5000) {
        (tied %dbm)->reorganize();
        $count = 0;
        }

      $self->{'count'} = $count;
      }
    }
#---------------------------------------------------------------------

=head2 deleteTuple(Column $key) 

=over 4

=item * Column $key 

- The key for the tuple to retrieve, can be an L<database::Id> or 
L<database::StringCol>.

=back

Delete a tuple.  The function returns true or false depending on 
whether or not the tuple found and deleted.

=cut

#---------------------------------------------------------------------
  sub deleteTuple {
    my ($self, $key) = @_;
    $key = $key->getKeyAsBytes();
    local (*dbm) = $self->{'dbm'};
    if (defined $dbm{$key}) {
      delete $dbm{$key};
      return 1;
      }
    return 0;
    }
#---------------------------------------------------------------------

=head2 retrieveTuple(Column $key)

=over 4

=item * Column $key 

- The key for the tuple to retrieve, can be an L<database::Id> or 
L<database::StringCol>.

=back

Retrieve a tuple with the given key from the table.  This routine will 
retrieve a tuple from the table, or if the tuple is not found it will
return 0.  Use as follows.

   # we want to retrieve the tuple for the key "hi"
   $key = Id::fromString("hi");
   # try to retrieve it 
   $r = $table->retrieveTuple($key);    
   # let's test if we found it
   if ($r) { 
     # key was found in the table 
   else { 
     # key was not found
     }

=cut 

#---------------------------------------------------------------------
  sub retrieveTuple {
    my ($self, $key) = @_;
    my ($keyAsBytes) = $key->toBytes();
    local (*dbm) = $self->{'dbm'};
    #// Convert the key int to a byte array
    if (!defined $dbm{$keyAsBytes}) {
      return 0;
      }
    return new Tuple(new StringCol($keyAsBytes), new StringCol($dbm{$keyAsBytes}));
    }
#---------------------------------------------------------------------

=head2 IdIdImage()

Return a string of the key, value pairs (assumed to be Ids).

=cut

#---------------------------------------------------------------------
  sub IdIdImage {
    my ($self) = @_;
    my ($result) = "Key,Value Image for Table:\n";
    local (*dbm) = $self->{'dbm'};
    my ($key);
    my ($valueAsBytes);
    foreach $key (keys %dbm) {
      $valueAsBytes = $dbm{$key};
      $result .= $key->toString() + ",";
      $result .= $valueAsBytes->toString() + "\n";
      }
    return $result;
    }
#---------------------------------------------------------------------

=head2 IdIdListImage()

Return a string of the key, value pairs (assumed to be Id Lists).

=cut

#---------------------------------------------------------------------
  sub IdIdListImage {
    my ($self) = @_;
    local (*dbm) = $self->{'dbm'};
    my ($result) = "Key,Value List Image for Table:\n";
    my ($key);
    my ($valueAsBytes);
    my ($idList);
    foreach $key (keys %dbm) {
      $valueAsBytes = $dbm{$key};
      $idList = IdList::fromBytes($valueAsBytes);
      $result .= $key + "," .  $idList->image() . "\n";
      }
    return $result;
    }
#---------------------------------------------------------------------

=head2 enumerate()

Return a reference to the dbm file.

=cut

#---------------------------------------------------------------------
  sub enumerate {
    my ($self) = @_;
    local (*dbm) = $self->{'dbm'};
    return \%dbm;
    }
#---------------------------------------------------------------------

=head2 enumerateKeys()

Return a list of the keys.

=cut

#---------------------------------------------------------------------
  sub enumerateKeys {
    my ($self) = @_;
    local (*dbm) = $self->{'dbm'};
    return keys %dbm;
    }
#---------------------------------------------------------------------

=head2 enumerateKeysAsInts()

Return a list of the key values, but as integer values rather than byte
sequences.

=cut

#---------------------------------------------------------------------
  sub enumerateKeysAsInts {
    my ($self) = @_;
    local (*dbm) = $self->{'dbm'};
    my $list = [];
    my $key;
    foreach $key (keys %dbm) {
      push @$list, $key + 0;
      }
    return $list;
    }
#---------------------------------------------------------------------

=head2 KeysAsStringIds()

Return a string of the key values (assumed to be Ids).

=cut

#---------------------------------------------------------------------
  sub KeysAsStringIds {
    my ($self) = @_;
    my ($result) = "";
    local (*dbm) = $self->{'dbm'};
    my ($key);
    my ($valueAsBytes);
    my $SEPARATOR = "";
    foreach $key (keys %dbm) {
      #$valueAsBytes = $dbm{$key};
      my ($id) = new Id $key;
      $result .= $SEPARATOR . $id->toString();
      $SEPARATOR = "\f";
      }
    return $result;
    }
#---------------------------------------------------------------------

=head2 save()

Close the DBM file

=cut 

#---------------------------------------------------------------------
  sub save {
    my ($self) = @_;
    local (*dbm) = $self->{'dbm'};

    #dbmclose %dbm;
    untie %dbm;
    }
#---------------------------------------------------------------------

=head2 IdKeysImage()

Return a string of the key values (assumed to be Ids).

=cut

#---------------------------------------------------------------------
  sub IdKeysImage {
    my ($self) = @_;
    my ($result) = "";
    local (*dbm) = $self->{'dbm'};
    my ($key);
    my ($valueAsBytes);
    my $SEPARATOR = "";
    foreach $key (keys %dbm) {
      #$valueAsBytes = $dbm{$key};
      my $id = new Id($key);
      $result .= $SEPARATOR . $id->image();
      $SEPARATOR = "\f";
      }
    return $result;
    }
#---------------------------------------------------------------------

1;
