set terminal postscript eps "Times-Roman" 18
set output '/home/curtis/tods/graphs/Random.ps'
set size 1.3,1.3
set tics out
set border
set nokey
set data style lines
set noparametric
set hidden3d
set ticslevel 0
set zrange [0:5000]
#set xrange [0:50]
set yrange [0:50]
set ztics 500, 500, 5000
set xtics 5, 5, 55
set ytics ("1" 0, "25" 12, "50" 25, "75" 37, "100" 49)
set xlabel "Size of Random Space" 0,-1
set label 1 "(in Periods of Indeterminacy)" at 21,-27,0
set ylabel "Plausibility" 
set zlabel "Machine Cycles" -5, -3
splot 'RandomTest.data'
