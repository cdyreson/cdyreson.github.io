/** Standard java packages for Collections */
import java.util.*;

/** Standard java packages for IO */
import java.io.*;

/** W3C packages for DOM trees */
import org.w3c.dom.*;

public class Match {
  private static TypeRecord xTrecord;
  private static TypeRecord yTrecord;
  private static NodeRecord xNrecord;
  private static NodeRecord yNrecord;

  //private static int totalPairsGlobal = 0;
  //private static int matchedPairsGlobal = 0;
  private static HashSet xmatchedGlobal = new HashSet();
  private static HashSet ymatchedGlobal = new HashSet();

  private static HashMap xtypeStatus = new HashMap();
  private static HashMap ytypeStatus = new HashMap();
  private static HashSet xUntried = new HashSet();
  private static HashSet yUntried = new HashSet();

  /** Print writer. */
  private static PrintStream fOut = System.out;

  public static void main(String argv[]) {
    if (argv.length < 2) {
      printUsage();
      System.exit(1);
    }

    String filex = argv[0];
    String filey = argv[1];
    long start = System.currentTimeMillis();

    /** max number of floors initialized to 10;
     *  if files are very "high", use larger numbers */
    Doc x = new Doc(10);
    Doc y = new Doc(10);

    x.mainProcess(filex);
    y.mainProcess(filey);

    //long mainProcess = System.currentTimeMillis();
    long mainProcessTimeMillis = System.currentTimeMillis() - start;
    float mainProcessTimeSec = mainProcessTimeMillis / 1000F;
    //CURT fOut.println();
    fOut.println(" time elapsed during mainProcess: " + mainProcessTimeSec + " seconds");

    /** we match element nodes and document nodes */
    // SHUOHAO int xsize = x.elemNodeNumber + 1;
    // SHUOHAO int ysize = y.elemNodeNumber + 1;
    int xsize = x.elemNodeNumber;
    int ysize = y.elemNodeNumber;

    xTrecord = x.trecord;
    yTrecord = y.trecord;
    xNrecord = x.nrecord;
    yNrecord = y.nrecord;

    ArrayList xAbbTypes = xTrecord.abbTypes;
    ArrayList yAbbTypes = yTrecord.abbTypes;

    if (argv.length == 2) {
      // matching for the entire two documents
      for (int i = 0; i < xAbbTypes.size(); i++) {
        AbbType xAbbType = (AbbType) xAbbTypes.get(i);
        if ( (xAbbType != null) && (xAbbType.name != "#text")) {
          AbbType yAbbType = getAbbType(yAbbTypes, xAbbType.name);
          if (yAbbType != null) {
            HashSet xNodes = xAbbType.nodes;
            HashSet yNodes = yAbbType.nodes;
            typeIdMatch(xNodes, yNodes);
          } // if (yAbbType != null)
        } // if
      } // for

      //fOut.println("xtypeStatus: " + xtypeStatus);

      //fOut.println("ytypeStatus: " + ytypeStatus);

      ArrayList xtypes = xTrecord.types;
      ArrayList ytypes = yTrecord.types;
      for (int i = 0; i < xtypes.size(); i++) {
        Type xtype = (Type) xtypes.get(i);
        //fOut.println(xtype.name);
        if ( (xtype != null) && (!xtype.name.endsWith("/"))) {
          if (xtypeStatus.get(xtype.name) == null) {
            xUntried.add(xtype);
          }
        }
      }
      for (int i = 0; i < ytypes.size(); i++) {
        Type ytype = (Type) ytypes.get(i);
        //fOut.println(ytype.name);
        if ( (ytype != null) && (!ytype.name.endsWith("/"))) {
          if (ytypeStatus.get(ytype.name) == null) {
            yUntried.add(ytype);
          }
        }
      }
      //fOut.println("xUntried: " + xUntried);
      //fOut.println("yUntried: " + yUntried);
      Iterator xUntriedIt = xUntried.iterator();

      while (xUntriedIt.hasNext()) {
        Type xtype = (Type) xUntriedIt.next();
        //fOut.println("xUntried: " + xtype.name);
        Iterator yUntriedIt = yUntried.iterator();
        while (yUntriedIt.hasNext()) {
          Type ytype = (Type) yUntriedIt.next();
          //fOut.println("yUntried: " + ytype.name);
          typeTerritoryMatch(xtype.nodes, ytype.nodes);
        }
      }

// print out overall statistics

      //CURT fOut.println(
      //CURT     "  *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** ");
      //CURT fOut.println(
      //CURT     "  *** *** *** *** *** OVERALL STATISTICS  *** *** *** *** *** ");

      //CURT fOut.println("  *** *** ");
      /*
       fOut.println("  *** *** Out of " + totalPairsGlobal +
                               " possible pairings of nodes, there are " +
                               matchedPairsGlobal + ", or " +
                               (double) matchedPairsGlobal * 100 /
                               (double) totalPairsGlobal +
                               "%, matched pairs. ");
       fOut.println("  *** *** (Two nodes with the same abbreviated type, ");
       fOut.println("  *** *** i.e., same name, are considered a possible pair.) ");
                  fOut.println("  *** *** ");
       */
      fOut.println("  *** *** Out of " + xsize +
                   " nodes in document one, " +
                   xmatchedGlobal.size() + ", or " +
                   (double) xmatchedGlobal.size() * 100 / (double) xsize +
                   "%, " +
                   "are matched.");
      //CURT fOut.println("  *** *** ");
      fOut.println("  *** *** Out of " + ysize +
                   " nodes in document two, " +
                   ymatchedGlobal.size() + ", or " +
                   (double) ymatchedGlobal.size() * 100 / (double) ysize +
                   "%, " +
                   "are matched.");

      //CURT fOut.println("  *** *** ");
      //CURT fOut.println(
      //CURT     "  *** *** *** ***  END OF OVERALL STATISTICS  *** *** *** *** ");
      //CURT fOut.println(
      //CURT     "  *** *** *** *** *** *** *** *** *** *** *** *** *** *** ***");

    } // if
    else { // there is a third argument
      /** matching for a specific type of element between two documents */
      String elemName = argv[2];
      AbbType xAbbType = getAbbType(xAbbTypes, elemName);
      AbbType yAbbType = getAbbType(yAbbTypes, elemName);
      if (xAbbType == null) {
        System.err.println("  there is no " + elemName + " node in file one.");
      }
      else if (yAbbType == null) {
        System.err.println("  there is no " + elemName + " node in file two.");
      }
      else {
        HashSet xNodes = xAbbType.nodes;
        HashSet yNodes = yAbbType.nodes;
        typeIdMatch(xNodes, yNodes);
      } // else

    } // else

    long elapsedTimeMillis = System.currentTimeMillis() - start;
    float elapsedTimeSec = elapsedTimeMillis / 1000F;
    //CURT fOut.println();
    fOut.println(" total time elapsed: " + elapsedTimeSec + "seconds");
  } // main

  private static AbbType getAbbType(ArrayList abbTypes, String name) {
    /*
         fOut.println("name: "+name);
         fOut.println("abbTypes: ");
         for (int i=0; i<abbTypes.size();i++) {
      AbbType x = (AbbType)abbTypes.get(i);
      x.printInfo();
         }
     */
    for (int i = 0; i < abbTypes.size(); i++) {
      AbbType atype = (AbbType) abbTypes.get(i);
      if (atype.name.equals(name)) {
        return atype;
      }
    }
    // System.err.println("no such abbreviated type is found! ");
    return null;
  }

  /** nodeMatch based on previous implementation of node territory,
   *  which is not space-efficient. */
  private static boolean nodeMatch(Node xnode, Node ynode) {
    HashSet xIdEval = (HashSet) xNrecord.nodeToIdEvaluation.get(xnode);
    HashSet yIdEval = (HashSet) yNrecord.nodeToIdEvaluation.get(ynode);
    HashSet xTerritory = (HashSet) xNrecord.nodeToTerritory.get(xnode);
    HashSet yTerritory = (HashSet) yNrecord.nodeToTerritory.get(ynode);

    fOut.println("  IdEval for node one: " + xIdEval);
    fOut.println("  Territory for node two: " + yTerritory);

    fOut.println("  IdEval for node two: " + yIdEval);
    fOut.println("  Territory for node one: " + xTerritory);

    if (setInclusion(yTerritory, xIdEval) && setInclusion(xTerritory, yIdEval)) {
      /*
                  fOut.println(" a match has been found for ");
                  fOut.println(" node " + xnode);
                  fOut.println(" in file one, and ");
                  fOut.println(" node " + ynode);
                  fOut.println(" in file two ");
       */
      return true;
    }
    else {
      return false;
    }
  }

  /** nodeMatch, only one shared area is stored for each type */
  private static boolean nodeMatch2(Node xnode, Node ynode) {
    HashSet xIdEval = (HashSet) xNrecord.nodeToIdEvaluation.get(xnode);
    HashSet yIdEval = (HashSet) yNrecord.nodeToIdEvaluation.get(ynode);
    HashSet xShared = xTrecord.nodeToType(xnode).sharedAreaValues;
    HashSet yShared = yTrecord.nodeToType(ynode).sharedAreaValues;

    HashSet x1 = setDifference(xIdEval, yIdEval);
    HashSet x2 = setDifference(x1, yShared);
    if (x2.size() != 0) return false;

    HashSet y1 = setDifference(yIdEval, xIdEval);
    HashSet y2 = setDifference(y1, xShared);
    if (y2.size() != 0) return false;
    return true;

// CURT SLOW HashSet xTerritory = setUnion(xIdEval, xShared);
// CURT SLOW    HashSet yTerritory = setUnion(yIdEval, yShared);

// CURT SLOW    if (setInclusion(yTerritory, xIdEval) && setInclusion(xTerritory, yIdEval)) {
      /*
            fOut.println(" a match has been found for ");
            fOut.println(" node " + xnode);
            fOut.println(" in file one, and ");
            fOut.println(" node " + ynode);
            fOut.println(" in file two ");
       */
// CURT SLOW      return true;
// CURT SLOW    }
// CURT SLOW    else {
// CURT SLOW      return false;
// CURT SLOW    }
  }

  /** Prints the usage. */
  private static void printUsage() {
    System.err.println("usage: please input two URL's for two XML documents, ");
    System.err.println("followed by the element name that you wish to match.");
    System.err.println();
  } // printUsage()

  private static boolean setContainsString(HashSet set, String string) {
    Iterator it = set.iterator();
    while (it.hasNext()) {
      String s = (String) it.next();
      if (s.compareTo(string) == 0) {
        //fOut.println(" set " + set + " contains string " + string);
        return true;
      }
    }
    return false;
  }

  /** test if set x includes set y.
   *  the complexity is |x|*|y|, but since y's size is usually very small
   *  (most often 1 or 2, rarely larger than 3 for large documents),
   *  it's not worth using a quicksort to first sort the set x.
   */
  private static boolean setInclusion(HashSet x, HashSet y) {
    Iterator yit = y.iterator();
    while (yit.hasNext()) {
      String yString = (String) yit.next();
      if (!setContainsString(x, yString)) {
        //fOut.println(" set " + y + " is not a subset of set " + x);
        return false;
      }
    }
    return true;
  }

  private static HashSet setIntersection(HashSet a, HashSet b) {
    if (a == null) {
      return a;
    }
    if (b == null) {
      return b;
    }

    HashSet result = new HashSet();
    Iterator ait = a.iterator();
    while (ait.hasNext()) {
      Node s = (Node) ait.next();
      if (b.contains(s)) {
        result.add(s);
        }
      }
    return result;
  }

  private static HashSet setDifference(HashSet a, HashSet b) {
    if (a == null) {
      return a;
    }
    if (b == null) {
      return a;
    }

    HashSet result = new HashSet();
    Iterator ait = a.iterator();
    while (ait.hasNext()) {
      String s = (String) ait.next();
      if (!b.contains(s)) {
        result.add(s);
        }
      } 
    return result;
  }

  private static HashSet setUnion(HashSet a, HashSet b) {
    if (a == null) {
      return b;
    }
    if (b == null) {
      return a;
    }

    HashSet result = new HashSet();
    Iterator ait = a.iterator();
    while (ait.hasNext()) {
      result.add( (String) ait.next());
    }
    Iterator bit = b.iterator();
    while (bit.hasNext()) {
      result.add( (String) bit.next());
    }
    return result;
  }

  private static void typeIdMatch(HashSet xnodes, HashSet ynodes) {
    //int totalPairs = 0;
    Boolean t = new Boolean(true);

    //System.out.println("TypdeIDMatch");
    Iterator xit = xnodes.iterator();
    Iterator yit = ynodes.iterator();
    Node ytnode = (Node) yit.next();
    Type ytype = yTrecord.nodeToType(ytnode);
    while (xit.hasNext()) {
      Node xnode = (Node) xit.next();
      Type xtype = xTrecord.nodeToType(xnode);
      HashSet xIdValue = (HashSet) xNrecord.nodeToIdEvaluation.get(xnode);

      if ( (ytype.name.compareTo(xtype.name) == 0) &&
            ytype.id.equals(xtype.id)) {
          xtypeStatus.put(xtype.name, t);
          ytypeStatus.put(ytype.name, t);
       Node ynode = (Node) ytype.map.get(xIdValue);
       if (ynode != null) {
            //matchedPairsGlobal++;
            xmatchedGlobal.add(xnode);
            ymatchedGlobal.add(ynode);
          }
          /*
                    fOut.println("  These two nodes are matched:");
                    fOut.println("  in file one: " + xnode);
                    fOut.println("  in file two: " + ynode);
           */
        } // if

        /*        else {
                  xtypeStatus.put(xtype, f);
                  ytypeStatus.put(ytype, f);
                }
         */
        //fOut.println("  ------------------------------------------------ ");

        /*        else {
                  fOut.println(" These two nodes are not matched:");
                  fOut.println(" in file one " + xnode);
                  fOut.println(" in file two " + ynode);
                }
         */
    } // while (xit.hasNext())

  } // typeIdMatch

  private static void typeTerritoryMatch(HashSet xnodes, HashSet ynodes) {
    //fOut.println("in typeTerrirotyMatch");
    //int totalPairs = 0;
    //int matchedPairs = 0;
    //int xsize = xnodes.size();
    //int ysize = ynodes.size();
    //HashSet xmatched = new HashSet();
    //HashSet ymatched = new HashSet();

    // First build a hash table that maps individual string values
    // in an identifier for a ynode to that ynode
    // So ynodesHash is "id value" ---> {set of nodes}
    Hashtable ynodesHash = new Hashtable();
    Iterator yit = ynodes.iterator();
    while (yit.hasNext()) {
      Node ynode = (Node) yit.next();
      if (ynode.getNodeType() == Node.DOCUMENT_NODE)
        return;
      HashSet yIdEval = (HashSet) yNrecord.nodeToIdEvaluation.get(ynode);
      Iterator yeval = yIdEval.iterator();
      while (yeval.hasNext()) {
        String s = (String) yeval.next();
        if (ynodesHash.containsKey(s)) { 
          HashSet h = (HashSet) ynodesHash.get(s);
          h.add(ynode);
          ynodesHash.put(s,h);
          }
        else {
          HashSet h = new HashSet();
          h.add(ynode);
          ynodesHash.put(s,h);
          }
        }
      } 

    // Next, iterate through all of xnodes, for each xnode use the hash table 
    // built previously to quickly identify "possible" ynodes
    Iterator xit = xnodes.iterator();
    while (xit.hasNext()) {
      Node xnode = (Node) xit.next();
      HashSet xIdEval = (HashSet) xNrecord.nodeToIdEvaluation.get(xnode);
      Iterator xeval = xIdEval.iterator();
      HashSet xUnmatched = new HashSet();
      HashSet yPossible = null;
      while (xeval.hasNext()) {
        String s = (String) xeval.next();
        if (ynodesHash.containsKey(s)) { 
          HashSet y = (HashSet) ynodesHash.get(s);
          if (yPossible == null) {    
            yPossible = y;
            }
          else {
            yPossible = setIntersection(yPossible, y);
            }
          }
        else {
          xUnmatched.add(s);
          }
        }

      // If we have some possible matches, evaluate further
      if (yPossible != null && yPossible.size() > 0) {
        Iterator ypit = yPossible.iterator();
        while (ypit.hasNext()) {
          Node ynode = (Node) ypit.next();
          if (xUnmatched.size() == 0) {
            xmatchedGlobal.add(xnode);
            ymatchedGlobal.add(ynode);
            }
          else {
            // Still stuff to match
            HashSet yShared = yTrecord.nodeToType(ynode).sharedAreaValues;
            if (setInclusion(yShared,xUnmatched)) {
              xmatchedGlobal.add(xnode);
              ymatchedGlobal.add(ynode);
              }
            }
          }
        }
      }
  } // typeMatch

} // Match
