/** Standard java packages for Containers */
import java.util.*;

/** Standard java packages for IO */
import java.io.*;

/** W3C packages for DOM trees */
import org.w3c.dom.*;

public class TypeRecord {

  /** List of Type objects. */
  ArrayList types;

  /** List of abbreviated Type objects. */
  ArrayList abbTypes;

  /** Maps Nodes to corresponding Types (Node->String). */
  private HashMap nodeToTypeNameMap;

  /** Print writer. */
  private static PrintStream fOut = System.out;

  TypeRecord() {
    types = new ArrayList();
    abbTypes = new ArrayList();
    nodeToTypeNameMap = new HashMap();
  }

  void printL() {
    ListIterator it = types.listIterator();
    while (it.hasNext()) {
      Type type = (Type) it.next();
      isId(type, type.typeL);
    }
  }

//  boolean isId(String typeName, TreeSet typeL) {
//  	Type type = typeNameToType(typeName);
//  	HashSet nodes = type.nodes;
//  	TreeSet typeL = type.typeL;
//  	return true;
//  }

  boolean isId(Type type, TreeSet typeL) {
    HashSet nodes = type.nodes;
    if (nodes.size() == 1) {
      return true;
    }

    ArrayList nodeArray = new ArrayList();
    ArrayList all = new ArrayList();

    Iterator it = nodes.iterator();
    while (it.hasNext()) {
      Node node = (Node) it.next();
      nodeArray.add(node);
    }

    int size = nodeArray.size();
    //fOut.println(" size: "+size);

    for (int i = 0; i < size; i++) {
      ArrayList eval = evalPathSet( (Node) nodeArray.get(i), typeL);
      all.add(eval);
    }

    quicksort(all, 0, size - 1);

    for (int i = 0; i < size - 1; i++) {
      ArrayList s = (ArrayList) all.get(i);
      ArrayList t = (ArrayList) all.get(i + 1);
      if (s.equals(t)) {
        return false;
      }
    }
    //fOut.println(typeL + " is Id for type '" + type.name + "' nodes");
    return true;
  }

  /** evaluate a set of path expression to a set of Node objects */
  HashSet evalPathSetToNodes(Node node, TreeSet typeL) {

    HashSet evalResult = new HashSet();

    Iterator it = typeL.iterator();
    while (it.hasNext()) {
      String exp = (String) it.next();
//		fOut.println(" node: "+node);
//		fOut.println(" exp: "+exp);
      HashSet pathResult = evalPathToNodes(node, exp);
      Iterator resultIt = pathResult.iterator();
      while (resultIt.hasNext()) {
        Node resultnode = (Node) resultIt.next();
        evalResult.add(resultnode);
      }
    }
    return evalResult;
  }

  /** evaluate a set of path expression to a list of sets of Nodes */
  ArrayList evalPathSet(Node node, TreeSet typeL) {
    ArrayList evalResult = new ArrayList();

    Iterator it = typeL.iterator();
    while (it.hasNext()) {
      String exp = (String) it.next();
//		fOut.println(" Hi ");
//		fOut.println(" node: "+node);
//		fOut.println(" exp: "+exp);
      TreeSet pathResult = evalPath(node, exp);
//		fOut.println(" Bye ");
//		fOut.println(" from node " + node + " the expression '" + exp + "' evaluates to: " + pathResult);
      evalResult.add(pathResult);
    }
    return evalResult;

  }

  /** evaluate a path expression to a set of text values (String objects) */
  TreeSet evalPath(Node node, String path) {
    if (path.startsWith("..")) {
      return evalUpwardPath(node, path);
    }
    else {
      return evalDownwardPath(node, path);
    }
  }

  /** evaluate an upward path expression to a set of text values (String objects) */
  TreeSet evalUpwardPath(Node node, String path) {

    String[] tokens = delimPath(path);

    // deal with each element name (all tokens except the last one: "text()") in the expression
    for (int i = 0; i < ( (tokens.length) - 1); i++) {
      if (tokens[i] == "..") {
        node = node.getParentNode();
        path = path.substring(3);
      }
      else break;
    }
    return evalDownwardPath(node, path);

  } // evalUpwardPath

  /** evaluate a downward path expression to a set of text values (String objects).
   *  it is also used by evalUpwardPath */
  TreeSet evalDownwardPath(Node node, String path) {
    TreeSet textResult = new TreeSet();
    String[] tokens = delimPath(path);

//  	fOut.println("tokens for expression '" + path + "':");
//  	for (int x=0; x<tokens.length; x++)
//         fOut.println(tokens[x]);
    ArrayList curNodes = new ArrayList();
    curNodes.add(node);
    ArrayList nextNodes = new ArrayList();

// deal with each element name (all tokens except the last one: "text()") in the expression
    for (int i = 0; i < ( (tokens.length) - 1); i++) {

      //fOut.println("#" + i + " token: " + tokens[i]);
      // deal with each node in curNodes
      for (int j = 0; j < curNodes.size(); j++) {
        Node n = (Node) curNodes.get(j);
        //fOut.println("#" + j + " current node: " + n);
        NodeList children = n.getChildNodes();

        // deal with each child of a node in curNodes,
        //  if a nodetest for node name returns true, add this child to nextNodes
        for (int k = 0; k < children.getLength(); k++) {
          Node child = children.item(k);
          //fOut.println("child node type: " + child.getNodeType());
          //fOut.println("child node name: " + child.getNodeName());
          if ( (child.getNodeType() == Node.ELEMENT_NODE) &&
              child.getNodeName().equals(tokens[i])) {
            nextNodes.add(child);

            //fOut.println("#" + k + " next node: " + child);
          }
        } // for k
      } // for j
      //fOut.println(" round "+i+", nextNodes are: "+nextNodes);
      // if nothing is added to nextNodes, the evaluation returns an empty result
      if (nextNodes.size() == 0) {
        return textResult;
      }
      else {
        /** nextNodes becomes the curNodes for the next round */
        curNodes.clear();
        for (int x = 0; x < nextNodes.size(); x++) {
          curNodes.add(nextNodes.get(x));
        }
        /** clears nextNodes */
        nextNodes.clear();
      } // else
    } // for i

//fOut.println("current nodes: " + curNodes);

    for (int i = 0; i < curNodes.size(); i++) {
      Node bottomElem = (Node) curNodes.get(i);
      NodeList textChildren = bottomElem.getChildNodes();
      for (int j = 0; j < textChildren.getLength(); j++) {
        Node child = textChildren.item(j);
        if (child.getNodeType() == Node.TEXT_NODE) {
          textResult.add(child.getNodeValue());
        }
      }
    }

    return textResult;

  } // evalDownwardPath
  /** evaluate a path expression to a set of text values (String objects) */
  HashSet evalPathToNodes(Node node, String path) {
    if (path.startsWith("..")) {
      //fOut.println("up");
      return evalUpwardPathToNodes(node, path);
    }
    else {
      //fOut.println("down");
      return evalDownwardPathToNodes(node, path);
    }
  }

  /** evaluate an upward path expression to a set of text values (String objects) */
  HashSet evalUpwardPathToNodes(Node node, String path) {

    //fOut.println("in evalUpwardPathToNodes");
    String[] tokens = delimPath(path);

    // deal with each element name (all tokens except the last one: "text()") in the expression
    for (int i = 0; i < ( (tokens.length) - 1); i++) {
      if (tokens[i].equals("..")) {
        node = node.getParentNode();
        path = path.substring(3);
        //fOut.println("node: "+node+" and path: "+path);

      }
      else break;
    }
    return evalDownwardPathToNodes(node, path);

  } // evalUpwardPath

  /** evaluate a path expression to a set of text nodes (Node objects) */
  HashSet evalDownwardPathToNodes(Node node, String path) {
    HashSet textResult = new HashSet();
    String[] tokens = delimPath(path);

//  	fOut.println("tokens for expression '" + path + "':");
//  	for (int x=0; x<tokens.length; x++)
//         fOut.println(tokens[x]);
    ArrayList curNodes = new ArrayList();
    curNodes.add(node);
    ArrayList nextNodes = new ArrayList();

    // deal with each element name (all tokens except the last one: "text()") in the expression
    for (int i = 0; i < ( (tokens.length) - 1); i++) {

      //fOut.println("#" + i + " token: " + tokens[i]);
      // deal with each node in curNodes
      for (int j = 0; j < curNodes.size(); j++) {
        Node n = (Node) curNodes.get(j);
        //fOut.println("#" + j + " current node: " + n);
        NodeList children = n.getChildNodes();

        // deal with each child of a node in curNodes,
        //  if a nodetest for node name returns true, add this child to nextNodes
        for (int k = 0; k < children.getLength(); k++) {
          Node child = children.item(k);
          //fOut.println("child node type: " + child.getNodeType());
          //fOut.println("child node name: " + child.getNodeName());
          if ( (child.getNodeType() == Node.ELEMENT_NODE) &&
              child.getNodeName().equals(tokens[i])) {
            nextNodes.add(child);

            //fOut.println("#" + k + " next node: " + child);
          }
        } // for k
      } // for j
      //fOut.println(" round "+i+", nextNodes are: "+nextNodes);
      // if nothing is added to nextNodes, the evaluation returns an empty result
      if (nextNodes.size() == 0) {
        return textResult;
      }
      else {
        /** nextNodes becomes the curNodes for the next round */
        curNodes.clear();
        for (int x = 0; x < nextNodes.size(); x++) {
          curNodes.add(nextNodes.get(x));
        }
        /** clears nextNodes */
        nextNodes.clear();
      } // else
    } // for i

    //fOut.println("current nodes: " + curNodes);

    for (int i = 0; i < curNodes.size(); i++) {
      Node bottomElem = (Node) curNodes.get(i);
      NodeList textChildren = bottomElem.getChildNodes();
      for (int j = 0; j < textChildren.getLength(); j++) {
        Node child = textChildren.item(j);
        if (child.getNodeType() == Node.TEXT_NODE) {
          textResult.add(child);
        }
      }
    }

    return textResult;
  } // evalPathToNodes

  String[] delimPath(String path) {
    String[] result = path.split("/");
    return result;
  }

  String nodeToTypeName(Node node) {
    return (String) nodeToTypeNameMap.get(node);
  }

  Type typeNameToType(String typeName) {
    ListIterator it = types.listIterator();
    while (it.hasNext()) {
      Type t = (Type) it.next();
      if (t.name.compareTo(typeName) == 0) {
        //System.out.println("type found");
        return t;
      }
    }
    System.err.println("no Type object found in typeNameToType for type: " +
                       typeName);
    return new Type("no such type in typeNameToType(String typeName)");
  }

  Type nodeToType(Node node) {
//  	String typeName = (String)nodeToTypeNameMap.get(node);
//  	Type t = (Type)typeNameToType(typeName);

    String typeName = (String) nodeToTypeNameMap.get(node);
    if (typeName == null) {
      System.err.println("no Type object found in nodeToType for node: " + node);
    }
    else {
      ListIterator it = types.listIterator();
      while (it.hasNext()) {
        Type t = (Type) it.next();
        if (t.name.compareTo(typeName) == 0) {
          //System.out.println("type found");
          return t;
        }
      }
    }
    return new Type("no such type in nodeToType(Node node)");
  }

  void printNodeToTypeNameMap() {
    System.out.println(nodeToTypeNameMap);
  }

  void addNodeInfo(Node node, String typeName) {
    updateType(node, typeName);
    updateAbbType(node);
  }

  private void updateType(Node node, String typeName) {
    ListIterator it = types.listIterator();
    while (it.hasNext()) {
      Type t = (Type) it.next();
      if (typeName.compareTo(t.name) == 0) {
        /** this type already exists */
        //System.out.println("old type found");
        t.addNode(node);
        nodeToTypeNameMap.put(node, typeName);
        return;
      }
    }

    /** this type is new */
    Type newType = new Type(typeName);
    newType.abbName = node.getNodeName();
    newType.addNode(node);
    types.add(newType);
    nodeToTypeNameMap.put(node, typeName);
  }

  private void updateAbbType(Node node) {
    ListIterator it = abbTypes.listIterator();
    while (it.hasNext()) {
      AbbType abbType = (AbbType) it.next();
      if (node.getNodeName().compareTo(abbType.name) == 0) {
        // this AbbType already exists
        //System.out.println("old type found");
        abbType.addNode(node);
        return;
      }
    }

    // this type is new
    AbbType newAbbType = new AbbType(node.getNodeName());
    newAbbType.name = node.getNodeName();
    newAbbType.addNode(node);

    abbTypes.add(newAbbType);
  }

  /** Quicksort. */
  void quicksort(ArrayList a, int left, int right) {
    if (right <= left) {
      return;
    }
    int i = partition(a, left, right);
    //System.out.println("partition: "+i);
    //System.out.println("array: "+a);
    quicksort(a, left, i - 1);
    //System.out.println("array after left: "+a);
    quicksort(a, i + 1, right);
    //System.out.println("array after right: "+a);
  }

  /** Quicksort partition. */
  int partition(ArrayList a, int left, int right) {
    int i = left - 1;
    int j = right;

    while (true) {

      // find item on left to swap
      while (arrayListLess( (ArrayList) a.get(++i), (ArrayList) a.get(right))) {
        ;
      }

      // find item on right to swap
      while (arrayListLess( (ArrayList) a.get(right), (ArrayList) a.get(--j))) {
        if (j == left) {
          break;
        }
      }

      // check if pointers cross
      if (i >= j) {
        break;
      }

      exch(a, i, j);
    }

    // swap with partition element
    exch(a, i, right);

    return i;
  }

  /** Tests if the first TreeSet is less than the second;
   *  each of the two is a TreeSet of String's.
   *  String's are compared lexicographically. */
  boolean treeSetLess(TreeSet a, TreeSet b) {
    //comparisons++;

    Iterator ait = a.iterator();
    Iterator bit = b.iterator();
    ArrayList arraya = new ArrayList();
    ArrayList arrayb = new ArrayList();

    while (ait.hasNext()) {
      arraya.add(ait.next());
    }
    while (bit.hasNext()) {
      arrayb.add(bit.next());
    }

    int n = Math.min(arraya.size(), arrayb.size());
    for (int i = 0; i < n; i++) {
      String stringa = (String) arraya.get(i);
      String stringb = (String) arrayb.get(i);
      if ( (stringa.compareTo(stringb) < 0)) {
        return true;
      }
      else if ( (stringa.compareTo(stringb) > 0)) {
        return false;
      }
    }
    return (arraya.size() < arrayb.size());
  } // less

  /** Tests if the first ArrayList is less than the second;
   *  each of the two is an ArrayList of TreeSet's. */
  boolean arrayListLess(ArrayList a, ArrayList b) {
    int n = Math.min(a.size(), b.size());
    for (int i = 0; i < n; i++) {
      TreeSet seta = (TreeSet) a.get(i);
      TreeSet setb = (TreeSet) b.get(i);
      if (treeSetLess(seta, setb)) {
        return true;
      }
      else if (treeSetLess(setb, seta)) {
        return false;
      }
    }
    return (a.size() < b.size());
  }

  /** Exchange two Object's in an ArrayList at positions i and j. */
  void exch(ArrayList a, int i, int j) {
    Object swap = a.get(i);
    a.set(i, a.get(j));
    a.set(j, swap);
  }

} // class TypeRecord
