/** Standard java packages for Containers */
import java.util.*;

/** Standard java packages for IO */
import java.io.*;

/** W3C packages for DOM trees */
import org.w3c.dom.*;

public class NodeRecord {

  /** Maps a Node to the evaluation of its id (Node->HashSet). */
  HashMap nodeToIdEvaluation;

  /** Maps a Node to the set of text values in its territory (Node->HashSet). */
  HashMap nodeToTerritory;

  /** Print writer. */
  private static PrintStream fOut = System.out;

  public NodeRecord() {
    nodeToIdEvaluation = new HashMap();
    nodeToTerritory = new HashMap();
  }

  public void printNodeToIdEvaluation() {
    //fOut.println(nodeToIdEvaluation);
    Set keys = (nodeToIdEvaluation.keySet());
    Iterator it = keys.iterator();
    while (it.hasNext()) {
      Node node = (Node) it.next();
      fOut.println();
      fOut.println(" The Id evaluation for Node " + node);
      fOut.println(" is " + nodeToIdEvaluation.get(node));
      fOut.println(" The territory for Node " + node);
      fOut.println(" is " + nodeToTerritory.get(node));
    }
  }

} // class NodeRecord
