/** Standard java packages for Containers */
import java.util.*;

/** Standard java packages for IO */
import java.io.*;

/** W3C packages for DOM trees */
import org.w3c.dom.*;

public class Type {

  String name; // name of Type: the concatenation of parent's Type and current nodeName
  String abbName; // abbreviated name of Type: the current nodeName
  HashSet nodes; // a set of Nodes of this type
  TreeSet typeL; // a set of XPath expressions
  TreeSet id; // a list of XPath expressions
  boolean done1; // indicates whether computation of id is completed in phase1
  boolean done2; // indicates whether computation of id is completed in phase2
  boolean attempted1; // indicates whether computation of id is attempted in phase1
  //Node lca; // the least common ancestor of all nodes of this type
  HashSet sharedAreaValues;
  HashMap map;	// maps an evaluated id (a set of Sting's) to a Node object

  public Type(String t) {
    name = t;
    abbName = new String();
    nodes = new HashSet();
    typeL = new TreeSet();
    id = new TreeSet();
    done1 = false;
    done2 = false;
    attempted1 = false;
    sharedAreaValues = new HashSet();
    map = new HashMap();
    //lca = new Node();
    //territory = new HashSet();
    //map = new HashMap();
  }

  void addNode(Node node) {
    Object obj = (Object) node;
    nodes.add(obj);
  }

  void printInfo() {
    fOut.println(" Info for type '" + name + "' nodes:");
    fOut.println();
    fOut.println(" abbreviated name: " + abbName);
    fOut.println();
    //fOut.println(" nodes: " + nodes);
    //fOut.println();
    fOut.println(" typeL: " + typeL);
    fOut.println();
    fOut.println(" id: " + id);
    fOut.println();
    fOut.println(" done in Phase 1: " + done1);
    fOut.println();
    fOut.println(" done in Phase 2: " + done2);
    //fOut.println();
    //fOut.println(" lca: " + lca);
    fOut.println();
    fOut.println(" sharedAreaValues: " + sharedAreaValues);
    fOut.println();
    fOut.println("map: " + map);
  }

//    public static void main (String argv[])
//    {
//      Type tt = new Type("a test type");
//      tt.id.add(new String("1st"));
//      tt.printInfo();
//    }

  /** Print writer. */
  private static PrintStream fOut = System.out;

} // class Type
