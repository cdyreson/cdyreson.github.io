/**
 * This program traverses a DOM tree and finds
 * (semantic) identifiers for all element nodes.
 */

/** Standard java packages for Collections */
import java.util.*;

/** Standard java packages for IO */
import java.io.*;

/** W3C packages for DOM trees */
import org.w3c.dom.*;

public class Doc {

  /** Print writer. */
  private static PrintStream fOut = System.out;

  /** Keeps track of all Type objects. */
  TypeRecord trecord = new TypeRecord();

  /** Keeps track of all Type objects. */
  NodeRecord nrecord = new NodeRecord();

  /** A list of set (floor.get(0) is a set of floor-0 nodes, etc.) */
  ArrayList floor = new ArrayList();

  /** A set of zero-floor, or, floor-0 nodes (text nodes)  */
  HashSet zeroFloor = new HashSet();

  int elemNodeNumber = 0;

  /** Nodes that are not assigned a floor yet. */
  private static Integer unassigned = new Integer( -1);

  /** Preset the max possible floor; this will be the length of ArrayList floor. */
  private int maxFloor;

  /** Maps Nodes to corresponding floor numbers (Node->Integer). */
  private HashMap nodeToFloor = new HashMap();

  public Doc() {
    maxFloor = 5;
  }

  public Doc(int f) {
    maxFloor = f;
  }

  /** Main processing method. */
  public void mainProcess(String file) {

    long start = System.currentTimeMillis();

    Document doc = MyParser.parse(file);
    long parse = System.currentTimeMillis();
    long parseTimeMillis = parse - start;
    float parseTimeSec = parseTimeMillis / 1000F;
    //CURT 
fOut.println(" parse: " + parseTimeSec + " seconds");

    preProcess(doc);
    //fOut.println(" preProcess done");
    long preProcess = System.currentTimeMillis();
    long preProcessTimeMillis = preProcess - parse;
    float preProcessTimeSec = preProcessTimeMillis / 1000F;
    //CURT 
fOut.println(" preProcess: " + preProcessTimeSec + " seconds");

    initFloor();
    //fOut.println(" initFloor done");
    long initFloor = System.currentTimeMillis();
    long initFloorTimeMillis = initFloor - preProcess;
    float initFloorTimeSec = initFloorTimeMillis / 1000F;
    //CURT 
fOut.println(" initFloor: " + initFloorTimeSec + " seconds");

    findFloor2(doc);
    //fOut.println(" findFloor(0) done");
    long findFloor = System.currentTimeMillis();
    long findFloorTimeMillis = findFloor - initFloor;
    float findFloorTimeSec = findFloorTimeMillis / 1000F;
    //CURT 
fOut.println(" findFloor: " + findFloorTimeSec + " seconds");

    findtypeL();
    //fOut.println(" findtypeL done");
    long findtypeL = System.currentTimeMillis();
    long findtypeLTimeMillis = findtypeL - findFloor;
    float findtypeLTimeSec = findtypeLTimeMillis / 1000F;
    //CURT 
fOut.println(" findtypeL: " + findtypeLTimeSec + " seconds");

    phase1();
    //fOut.println(" phase 1 done");
    long phase1 = System.currentTimeMillis();
    long phase1TimeMillis = phase1 - findtypeL;
    float phase1TimeSec = phase1TimeMillis / 1000F;
    //CURT 
fOut.println(" phase1: " + phase1TimeSec + " seconds");

    Node root = doc.getDocumentElement();
    phase2(root, root);
    //fOut.println(" phase 2 done");
    long phase2 = System.currentTimeMillis();
    long phase2TimeMillis = phase2 - phase1;
    float phase2TimeSec = phase2TimeMillis / 1000F;
    //CURT 
fOut.println(" phase2: " + phase2TimeSec + " seconds");

    findNodeTerritory2();
    //findNodeTerritory2();
    //fOut.println(" findNodeTerritory done");
    long findNodeTerritory = System.currentTimeMillis();
    long findNodeTerritoryTimeMillis = findNodeTerritory - phase2;
    float findNodeTerritoryTimeSec = findNodeTerritoryTimeMillis / 1000F;
    //CURT 
fOut.println(" findNodeTerritory: " + findNodeTerritoryTimeSec + " seconds");

    long end = System.currentTimeMillis();
    long totalTimeMillis = end - start;
    float totalTimeSec = totalTimeMillis / 1000F;
    fOut.println(" total time: " + totalTimeSec + " seconds");

    ////CURT fOut.println(" *** mainProcess for this document done *** ");
    //printFloor();
    //printTypeRecord();
    //printNodeRecord();
 /*
    Node node = doc.getFirstChild().getLastChild().getLastChild().getFirstChild();
    String path = "../../name/text()";
    fOut.println("test upward path");
    fOut.println("node: "+node);
    fOut.println("path: "+path);
    fOut.println(trecord.evalPathToNodes(node, path));
*/
  } // mainProcess

  /** Returns the distance between two ELEMENT nodes (supposingly a descendant and an ancestor).
   *  The result is 0 if the two parameters are the same node,
   *  and the result is -1 if the first parameter is not a descendant
   *  of the second parameter.
   *  Distance is the number of edges in between. */
  private int distance(Node descendant, Node ancestor) {
    int dist = 0;
    if (descendant == ancestor) {
      return dist;
    }
    Node tmp = descendant.getParentNode();
    while (tmp.getNodeType() != Node.DOCUMENT_NODE) {
      dist++;
      if (tmp == ancestor) {
        return dist;
      }
      else {
        tmp = tmp.getParentNode();
      }
    }
    return -1;
  }

  /** the old findNodeTerritory takes n-square space.
   *  find node territory for each node;
   *  this has to be after phase 1 and 2 are done. */
  private void findNodeTerritory2() {
    Iterator it = trecord.types.iterator();
    while (it.hasNext()) {
      Type type = (Type) it.next();

      HashSet shared = sharedAreaValues2(type);
      //fOut.println(" the sharedArea for type " + type.name + " is: ");
      //fOut.println(shared);
      type.sharedAreaValues = shared;
    } // while type
  } // findNodeTerritory

  /** find node territory for each node;
   *  this has to be after phase 1 and 2 are done. */
  private void findNodeTerritory() {
    Iterator it = trecord.types.iterator();
    while (it.hasNext()) {
      Type type = (Type) it.next();
      HashSet shared = sharedAreaValues(type);
      //fOut.println(" the sharedArea for type " + type.name + " is: ");
      //fOut.println(shared);

      HashSet nodes = type.nodes;
      Iterator nit = nodes.iterator();
      while (nit.hasNext()) {
        Node node = (Node) nit.next();
        Integer f = (Integer) nodeToFloor.get(node);

        /** floor zero (text) nodes do not have nodeToIdEvaluation */
        if (f.intValue() != 0) {
          HashSet textDesc = allTextDescValues(node);
          //fOut.println(" the text descendants for node " + node + " is: ");
          //fOut.println(evaluatedId);

          HashSet territory = setUnion(shared, textDesc);

          /** update nrecord.nodeToTerritory */
          nrecord.nodeToTerritory.put(node, territory);
          //fOut.println(" the territory for node " + node + " is: ");
          //fOut.println(territory);
        }
      } // while node
    } // while type
  } // findNodeTerritory

  /** get a set of all text descendants of a node */
  private HashSet allTextDescNodes(Node node) {
    HashSet result = new HashSet();
    result = collectTextNodes(node, result);
    return result;
  }

  /** utility method for allTextDesc(); get a set of all text nodes
   *  that are descendants of a node */
  private HashSet collectTextNodes(Node node, HashSet set) {

    short type = node.getNodeType();
    switch (type) {
      case Node.DOCUMENT_NODE: {
        Document document = (Document) node;
        collectTextNodes(document.getDocumentElement(), set);
        break;
      }
      case Node.ELEMENT_NODE: {

        Node child = node.getFirstChild();
        while (child != null) {
          collectTextNodes(child, set);
          child = child.getNextSibling();
        }
        break;
      }
      case Node.TEXT_NODE: {
        set.add(node);
        break;
      }
    }
    return set;
  }

  /** get a set of all text descendants of a node */
  private HashSet allTextDescValues(Node node) {
    HashSet result = new HashSet();
    result = collectTextValues(node, result);
    return result;
  }

  /** utility method for allTextDesc(); get a set of all text nodes
   *  that are descendants of a node */
  private HashSet collectTextValues(Node node, HashSet set) {

    short type = node.getNodeType();
    switch (type) {
      case Node.DOCUMENT_NODE: {
        Document document = (Document) node;
        collectTextValues(document.getDocumentElement(), set);
        break;
      }
      case Node.ELEMENT_NODE: {

        Node child = node.getFirstChild();
        while (child != null) {
          collectTextValues(child, set);
          child = child.getNextSibling();
        }
        break;
      }
      case Node.TEXT_NODE: {
        set.add(node.getNodeValue());
        break;
      }
    }
    return set;
  }

  Node getDoc() {
    Type t = trecord.typeNameToType("DOC");
    HashSet singletonSet = t.nodes;
    Iterator it = singletonSet.iterator();
    Node doc = (Node) it.next();
    return doc;
  }

  /** find lca for nodes of a certain type, in the subtree rooted at root */
  private Node findLca(Type type) {
    Node doc = getDoc();
    return lca(doc, type);
  }

  /** find lca for nodes of a certain type, in the subtree rooted at root */
  private Node lca(Node root, Type type) {
    Node lca = root;
    if (trecord.nodeToTypeName(lca).equals(type.name)) {

      // which means there is exactly one node of such type
      return lca;
    }

    for (int i = 0; i < lca.getChildNodes().getLength(); i++) {
      /** if lca's typename is a preifx of type's typename */
      if (type.name.startsWith(trecord.nodeToTypeName(lca))) {
        Node child = lca.getChildNodes().item(i);
        if (ca(child, type)) {
          lca = lca(child, type);
          return lca;
        }
      }
    }
    return lca;
  }

  /** if n is a common ancestor of nodes of a certain type */
  private boolean ca(Node n, Type type) {
    HashSet nodes = type.nodes;
    Iterator it = nodes.iterator();
    while (it.hasNext()) {
      Node node = (Node) it.next();
      if (distance(node, n) < 0) {
        return false;
      }
    }
    return true;
  }

  /** find lca for nodes of a certain type */
  private Node lca(Node root, String type) {
    Node lca = root;
    if (trecord.nodeToTypeName(lca).equals(type)) {

      // which means there is exactly one node of such type
      return lca;
    }

    for (int i = 0; i < lca.getChildNodes().getLength(); i++) {
      /** if lca's typename is a preifx of type */
      if (type.startsWith(trecord.nodeToTypeName(lca))) {
        Node child = lca.getChildNodes().item(i);
        if (ca(child, type)) {
          lca = lca(child, type);
          return lca;
        }
      }
    }
    return lca;
  }

  /** if n is a common ancestor of nodes of a certain type */
  private boolean ca(Node n, String type) {
    HashSet nodes = trecord.typeNameToType(type).nodes;
    Iterator it = nodes.iterator();
    while (it.hasNext()) {
      Node node = (Node) it.next();
      if (distance(node, n) < 0) {
        return false;
      }
    }
    return true;
  }

  /** after floor is computed, find typeL for all nodes */
  private void findtypeL() {

    Iterator it = zeroFloor.iterator();

    while (it.hasNext()) {
      Node node = (Node) it.next();

      String nodeTypeL = "text()";
      Type t = trecord.nodeToType(node);
      //t.printInfo();
      t.typeL.add(nodeTypeL);

      Node parent = node.getParentNode();
      while (parent.getNodeType() != Node.DOCUMENT_NODE) {
        String name = parent.getNodeName();
        t = trecord.nodeToType(parent);
        t.typeL.add(nodeTypeL);
        nodeTypeL = name + "/" + nodeTypeL;
        parent = parent.getParentNode();
      }
    }
  } // findtypeL()

  /** try to find Id for each node in phase1,
   *  update nrecord.nodeToIdEvaluation when an Id is found */
  private void phase1() {
    for (int i = 1; i < floor.size(); i++) {
      //fOut.println(" current floor: "+i);
      HashSet curFloor = (HashSet) floor.get(i);
      HashSet curFloorTypes = new HashSet();
      //fOut.println("content of floor " + i + " is " + curFloor);

      Iterator curFloorIt = curFloor.iterator();
      while (curFloorIt.hasNext()) {
        Node node = (Node) curFloorIt.next();
        Type nodetype = trecord.nodeToType(node);
        curFloorTypes.add(nodetype);
//    			fOut.println(" before if, floor " + i + " node: " + node);
//    			fOut.println(" type.done1: " + type.done1);
//    			fOut.println(" type: " + type + " trecord.isId(): "+ trecord.isId(type, type.typeL));
      }

      Iterator curFloorTypeIt = curFloorTypes.iterator();
      while (curFloorTypeIt.hasNext()) {
        Type type = (Type) curFloorTypeIt.next();
        if ( (!type.done1) && trecord.isId(type, type.typeL)) {
          // typeL is the id for this type
          type.id = type.typeL;
          //fOut.println(" id for type " + type.name + " is: " + type.id);
          // update nrecord.nodeToIdEvaluation for each node of such type;
          // all ancestors of each such node are mapped to the same set of text nodes.
          Iterator nit = type.nodes.iterator();
          while (nit.hasNext()) {
            Node n = (Node) nit.next();
            ArrayList eval = trecord.evalPathSet(n, type.id);
            HashSet textSet = flatten(eval);
            type.map.put(textSet, n);
            nrecord.nodeToIdEvaluation.put(n, textSet);
            //fOut.println(" phase 1: IdEval for node " + n + " is: " + textSet);
            updateAncestorId(n);
          }
          type.done1 = true;
          //fOut.println(" finished type: " + type.name);

          //fOut.println(" finished updateAncestors for type: " + type.name);
        } // if
      } // while (curFloorTypeIt.hasNext())
      //fOut.println(" after if, floor " + i + " node: " + node);
    } // for (int i = 1; i < floor.size(); i++)
  } // phase1

  /** in phase2, find Id for nodes not yet identified in phase1;
   *  update nrecord.nodeToIdEvaluation when an Id is found in this phase */
  private void phase2(Node root, Node cur) {
    Type rootType = trecord.nodeToType(root);
    Type curType = trecord.nodeToType(cur);
    NodeList children = cur.getChildNodes();
    String rootName = rootType.name;
    String curName = curType.name;
     /*
        fOut.println(" phase 2 with node: " + rootName);
        fOut.println(" and node: " + curName);
        fOut.println(" ****************************************** ");
     */

    /** breath-first */
    for (int i = 0; i < children.getLength(); i++) {
      Node child = children.item(i);

      if (child.getNodeType() != Node.TEXT_NODE) {
        Type childType = trecord.nodeToType(child);

        if (childType.done1) {
          phase2(child, child);
        }
        else if (!childType.done2) {
          /** iterator for child type typeL */
          Iterator cit = childType.typeL.iterator();
          while (cit.hasNext()) {
            String cexp = (String) cit.next();
            childType.id.add(cexp);
          } // while cit
          /** iterator for root type typeL */
          Iterator rit = rootType.id.iterator();
          while (rit.hasNext()) {
            String rexp = (String) rit.next();
            String chain = new String("");
            for (int j = 0; j < distance(child, root); j++) {
              chain = chain + "../";
            }
            String rootId = chain + rexp;
            childType.id.add(rootId);
          } // while rit

          /** childType's Id has been completely figured out;
           *  we can now update nrecord.nodeToIdEvaluation.
           */
          HashSet rootIdEval = (HashSet) nrecord.nodeToIdEvaluation.get(root);
          Iterator nit = childType.nodes.iterator();
          while (nit.hasNext()) {
            Node node = (Node) nit.next();
            if (distance(node, root) >= 0) {
              ArrayList eval = trecord.evalPathSet(node, childType.id);
              HashSet textSet = flatten(eval);
              HashSet nodeIdEval = setUnion(textSet, rootIdEval);
              nrecord.nodeToIdEvaluation.put(node, nodeIdEval);
              childType.map.put(nodeIdEval, node);
              //fOut.println(" phase2: IdEval for node " + node + " is: " + nodeIdEval);
            }
            else {
        // Look for a node of the root type.
        Node n = node;
        Type t = trecord.nodeToType(n);
        //fOut.println(" phase2: IdEval for node " + node + " root" + root);
        while (t != rootType) { 
          n = n.getParentNode(); 
          t = trecord.nodeToType(n); 
          }
        ArrayList eval = trecord.evalPathSet(node, childType.id);
        HashSet textSet = flatten(eval);
        HashSet rootTypeNodeIdEval = (HashSet) nrecord.
                      nodeToIdEvaluation.get(n);
        HashSet nodeIdEval = setUnion(textSet, rootTypeNodeIdEval);
        nrecord.nodeToIdEvaluation.put(node, nodeIdEval);
        childType.map.put(nodeIdEval, node);
        //fOut.println(" phase2: IdEval for node " + node + " is: " + nodeIdEval);
        /** there is exactly one rootTypeNode that is an ancestor of node */
            } // else
          } // while (nit.hasNext())

          childType.done2 = true;
          phase2(root, child);
        } // else if (!childType.done2)
      } // if (child.getNodeType() != Node.TEXT_NODE)
    } // for
  } // phase2

  /** Traverse the DOM tree recursively, finding the types and initializing floors. */
  private void preProcess(Node node) {

    /** is there anything to do? */
    if (node == null) {
      return;
    }

    short type = node.getNodeType();
    switch (type) {
      case Node.DOCUMENT_NODE: {

        Document document = (Document) node;
        trecord.addNodeInfo(node, "DOC");
        nodeToFloor.put(node, unassigned);
        preProcess(document.getDocumentElement());
        break;
      }

      case Node.ELEMENT_NODE: {
        elemNodeNumber++;

        // name of this node
        String nodeName = node.getNodeName();

        // get its parent node
        Node parent = node.getParentNode();
        // get parent's type
        String parentTypeName = (String) (trecord.nodeToTypeName(parent));
        // get this node's type
        String nodeTypeName = parentTypeName + "/" + nodeName;

        // add this node to trecord
        trecord.addNodeInfo(node, nodeTypeName);

        nodeToFloor.put(node, unassigned);
/*
        // if this is a level-1 node, deal with the text child's type
        if (bottomElement(node)) {
          NodeList children = node.getChildNodes();
          // text node's type ends with an "/"
          String childTypeName = nodeTypeName + "/";

          for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.TEXT_NODE) {
              trecord.addNodeInfo(child, childTypeName);
            }
          }
        }
*/
        Node child = node.getFirstChild();
        while (child != null) {
          preProcess(child);
          child = child.getNextSibling();
        }
        break;
      }

      case Node.TEXT_NODE: {
        /** all text nodes are floor-0 nodes */
        nodeToFloor.put(node, new Integer(0));
        zeroFloor.add(node);

        String parentTypeName = trecord.nodeToTypeName(node.getParentNode());
        String textNodeTypeName = parentTypeName + "/";

        trecord.addNodeInfo(node, textNodeTypeName);

        break;
      }

    }

  } // preProcess()


  /** check for each ancestor type if typeL is id  */
   private void updateAncestorId(Node node) {
     Type type = trecord.nodeToType(node);
     String name = type.abbName;
     Node parent = node.getParentNode();
     Type parentType = trecord.nodeToType(parent);

     //while ( (!parentType.done1) && (parent.getNodeType() == Node.ELEMENT_NODE)) {
     while ( (!parentType.done1) && (parent != null)) {
       //Type parentType = trecord.nodeToType(parent);
       //fOut.println(" in while loop  ");
       if (allANodesHasBChild(parentType, type)) {
         parentType.id = appendPrefix(name, type.id);
         //CURT fOut.println(" id for parentType " + parentType.name + " is: " + parentType.id);

         Iterator nit = parentType.nodes.iterator();
         while (nit.hasNext()) {
           Node n = (Node) nit.next();
           ArrayList eval = trecord.evalPathSet(n, parentType.id);
           HashSet textSet = flatten(eval);
           nrecord.nodeToIdEvaluation.put(n, textSet);
           parentType.map.put(textSet, n);
           //fOut.println(" IdEval for node " + n + " is: " + textSet);
         }

         parentType.done1 = true;
         //fOut.println(" updating ancestors for type: " + parentType.name);
         type = parentType;
         name = type.abbName;
         parent = parent.getParentNode();
         if (parent == null)
           return;
         parentType = trecord.nodeToType(parent);

       } // if
       else {
         break;
       }
       //flag = false;
     }
   } // updateAncestors

  /** check for each ancestor type if typeL is id  */
  private void updateAncestorId2(Node node) {
    Type type = trecord.nodeToType(node);
    String name = type.abbName;
    Node parent = node.getParentNode();
    Type parentType = trecord.nodeToType(parent);

    //while ( (!parentType.done1) && (parent.getNodeType() == Node.ELEMENT_NODE)) {
    while ( (!parentType.done1) && (parent != null)) {
      //Type parentType = trecord.nodeToType(parent);
      //fOut.println(" in while loop  ");
      if (allANodesHasBChild(parentType, type)) {
        parentType.id = appendPrefix(name, type.id);
        //fOut.println(" id for parentType " + parentType.name + " is: " + parentType.id);

        Iterator nit = parentType.nodes.iterator();
        while (nit.hasNext()) {
          Node n = (Node) nit.next();

          // !!!Change Here!!!
          // !!!To avoid n-square space, just store IdEvaluation of node,
          // !!!rather than all children of the same type of node.
          //ArrayList eval = trecord.evalPathSet(n, parentType.id);
          //HashSet textSet = flatten(eval);
          NodeList children = n.getChildNodes();
          for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeName() == name) {
              HashSet textSet = (HashSet) nrecord.nodeToIdEvaluation.get(child);
              nrecord.nodeToIdEvaluation.put(n, textSet);
              parentType.map.put(textSet, n);
              //fOut.println(" phase 1 updateAncestorId: IdEval for node " + node + " is: " + textSet);
              //fOut.println(" IdEval for node " + n + " is: " + textSet);
              break;
            }
          }
        }

        parentType.done1 = true;
        //fOut.println(" updating ancestors for type: " + parentType.name);
        type = parentType;
        name = type.abbName;
        parent = parent.getParentNode();
        parentType = trecord.nodeToType(parent);

      } // if
      else {
        break;
      }
      //flag = false;
    }
  } // updateAncestors

  /** transforms a list of sets to a flattened set */
  private HashSet flatten(ArrayList listOfSet) {
    HashSet result = new HashSet();
    for (int i = 0; i < listOfSet.size(); i++) {
      TreeSet set = (TreeSet) listOfSet.get(i);
      result.addAll(set);
    }
    return result;
  }

  /** if all type a nodes has at least one Type b child node */
  private boolean allANodesHasBChild(Type a, Type b) {
    HashSet allParentTypeNodes = a.nodes;
    Iterator it = allParentTypeNodes.iterator();
    while (it.hasNext()) {
      Node aTypeNode = (Node) it.next();
      NodeList children = aTypeNode.getChildNodes();

      if (!hasType(children, b)) {
        return false;
      }
    }
    return true;
  }

  /** if a NodeList of nodes contains a Type b node */
  private boolean hasType(NodeList nodes, Type b) {
    for (int i = 0; i < nodes.getLength(); i++) {
      Node node = nodes.item(i);
      if (trecord.nodeToType(node) == b) {
        return true;
      }
    }
    return false;
  }

  /** appendPrefix a string name+"/" in front of each expression in typeL,
   * where name is the element name */
  private TreeSet appendPrefix(String name, TreeSet typeL) {
    TreeSet result = new TreeSet();
    Iterator it = typeL.iterator();
    while (it.hasNext()) {
      String exp = (String) it.next();
      //fOut.println("exp: " + exp);
      String tmp = name + "/";
      String newExp = tmp.concat(exp);
      //fOut.println("new exp: " + newExp);
      result.add(newExp);
    }
    return result;
  }

  /** initialize floor variable */
  private void initFloor() {

    floor.add(0, zeroFloor);
    //floor.add(1, baseFloor);
    for (int i = 1; i <= maxFloor; i++) {
      floor.add(i, new HashSet());
    }
  }

  /** the old findFloor takes n-square time
   * find the floor number for each node */
  private int findFloor2(Node node) {
    if (node.getNodeType() == Node.TEXT_NODE) {
      nodeToFloor.put(node, new Integer(0));
      HashSet properFloor = (HashSet) floor.get(0);
      properFloor.add(node);
      return 0;
    }
    else {
      NodeList children = node.getChildNodes();
      int max = maxChildrenFloor(children);
      if (children.getLength() == 0) { // an element node with no child
        nodeToFloor.put(node, new Integer(1));
        HashSet properFloor = (HashSet) floor.get(1);
        properFloor.add(node);
        return 1;
      }

      else if (children.getLength() == 1) { // an element node with one child
        Node onlyChild = children.item(0);
        if (onlyChild.getNodeType() == Node.TEXT_NODE) { // an element node with one text child, floor 1
          nodeToFloor.put(node, new Integer(1));
          HashSet properFloor = (HashSet) floor.get(1);
          properFloor.add(node);
          return 1;
        }
        else { // an element node with one element child, same floor as child
          nodeToFloor.put(node, new Integer(max));
          HashSet properFloor = (HashSet) floor.get(max);
          properFloor.add(node);
          return max;
        }
      }
      else { // an element node with more than one child
        nodeToFloor.put(node, new Integer(max + 1));
        HashSet properFloor = (HashSet) floor.get(max + 1);
        properFloor.add(node);
        return max + 1;
      }
    }
  }

  private int maxChildrenFloor(NodeList nodes) {
    int max = 0;
    for (int i = 0; i < nodes.getLength(); i++) {
      int floor = findFloor2(nodes.item(i));
      if (floor > max) {
        max = floor;
      }
    }
    return max;
  }

  /** find the floor number for each node */
  private void findFloor(int start) {

    for (int i = start; i < maxFloor; i++) {

      HashSet curFloor = (HashSet) floor.get(i);

      Iterator it = curFloor.iterator();
      while (it.hasNext()) {

        Node node = (Node) it.next();
        Node parent = node.getParentNode();
        if (parent != null) {

          //NodeList children = parent.getChildNodes();
          ArrayList elemChildNodes = getElemChildNodes(parent);
          if (allAssignedFloor(elemChildNodes)) {

            if (elemChildNodes.size() == 1) {
              nodeToFloor.put(parent, new Integer(i));

              /** though the parent is put to nodeToFloor,
               *	the iterator won't visit this node.
               *	Thus the grandparent won't have a
               *	floor at all if the parent is its sole child.
                            //findFloor(i);
               */
            }
            else {
              int max = maxElemChildFloor(parent);
              nodeToFloor.put(parent, new Integer(max + 1));
              HashSet properFloor = (HashSet) floor.get(max + 1);
              properFloor.add(parent);
            }
          }
        }
      }
    }
  }

  /** Test if a list of nodes are all assigned a floor. */
  private boolean allAssignedFloor(ArrayList nodes) {
    ListIterator it = nodes.listIterator();
    while (it.hasNext()) {
      Node node = (Node) it.next();
      if (nodeToFloor.get(node) == unassigned) {
        return false;
      }
    }
    return true;
  }

  /** Return a list of all element children. */
  private ArrayList getElemChildNodes(Node node) {
    ArrayList elemChildNodes = new ArrayList();
    NodeList children = node.getChildNodes();
    for (int i = 0; i < children.getLength(); i++) {
      Node tmp = children.item(i);
      if (isElemNode(tmp)) {
        elemChildNodes.add(tmp);
      }
    }
    return elemChildNodes;
  }

  /** Test if a node is an element node. */
  private boolean isElemNode(Node node) {
    if (node.getNodeType() == Node.ELEMENT_NODE) {
      return true;
    }
    else {
      return false;
    }
  }

  /** Return the maximum floor of all element children. */
  private int maxElemChildFloor(Node node) {
    int max = 0;
    NodeList children = node.getChildNodes();
    for (int i = 0; i < children.getLength(); i++) {
      Node tmp = children.item(i);
      if (tmp.getNodeType() == Node.ELEMENT_NODE) {
        Integer tmpFloor = (Integer) (nodeToFloor.get(tmp));
        if ( (tmpFloor.intValue() > max) && isElemNode(tmp)) {
          max = tmpFloor.intValue();
        }
      } // if
    } // for
    return max;
  }

  /** Decide if a node is a bottom element: floor-1. */
  private boolean bottomElement(Node node) {
    NodeList children = node.getChildNodes();
    for (int i = 0; i < children.getLength(); i++) {
      if (isElemNode(children.item(i))) {
        return false;
      }
    }
    return true;
  }

  /** Print out the all Type objects. */
  private void printTypeRecord() {
    fOut.println();
    fOut.println("***Printing Type objects:***");
    Iterator it = trecord.types.iterator();
    while (it.hasNext()) {
      Type t = (Type) it.next();
      /** print info for all element types */
      if (!t.name.endsWith("/") && !t.name.equals("DOC")) {
        t.printInfo();
        fOut.println();
        fOut.println(
            "*** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** ***");
        fOut.println();
      }
    }
  } // printTypeRecord()

  /** Print out type names for all nodes. */
  private void printNodeToTypeName() {
    fOut.println();
    fOut.println("***Printing Node types:***");
    trecord.printNodeToTypeNameMap();
    fOut.println();
  } // printNodeToTypeName()

  /** Print out foor information for all nodes, starting from low to high. */
  private void printFloor() {
    fOut.println();
    fOut.println("***Printing Node floors:***");
    fOut.println(floor);
    fOut.println();
  } // printFloor()

  /** Print out evaluation of id for all nodes. */
  private void printNodeRecord() {
    fOut.println();
    fOut.println("***Printing NodeRecord:***");
    nrecord.printNodeToIdEvaluation();
    fOut.println();
  } // printNodeRecord()

  /** Prints the usage. */
  private void printUsage() {

    System.err.println("usage: uri");
    System.err.println();
  } // printUsage()

  private void evalPathTest(Document doc, String exp) {
    Node root = doc.getDocumentElement();
    fOut.println(" from root node: " + root);
    fOut.println(" expression: " + exp + " evaluates to: ");
    fOut.println(trecord.evalPath(root, exp));
  }

  private void lcaTest(Document doc, String type) {
    Node root = doc.getDocumentElement();
    //Node n = root.getChildNodes().item(1).getChildNodes().item(1).getChildNodes().item(1);
    //Node lca = lca(root, trecord.nodeToType(n));
    Node lca = lca(root, type);
    fOut.println(" the lca of type ");
    fOut.println(type);
    fOut.println(" is node " + lca);
  }

  private HashSet setUnion(HashSet a, HashSet b) {
    HashSet result = new HashSet();
    Iterator ait = a.iterator();
    while (ait.hasNext()) {
      result.add( (String) ait.next());
    }
    Iterator bit = b.iterator();
    while (bit.hasNext()) {
      result.add( (String) bit.next());
    }
    return result;
  }

  private void sharedAreaTest() {
    Iterator it = trecord.types.iterator();
    while (it.hasNext()) {
      Type t = (Type) it.next();
      fOut.println(" the sharedArea for type " + t.name + " is: ");
      fOut.println(sharedAreaValues(t));
    }
  }

  /** get the shared area of a certain type;
   *  the result is a set of nodes. */
  private HashSet sharedAreaNodes(Type type) {
    Node lca = findLca(type);
    HashSet all = allTextDescNodes(lca);
    Iterator it = type.nodes.iterator();
    while (it.hasNext()) {
      Node node = (Node) it.next();
      HashSet nodeIdNodes = trecord.evalPathSetToNodes(node, type.id);
      Iterator nit = nodeIdNodes.iterator();
      while (nit.hasNext()) {
        Node idNode = (Node) nit.next();
        all.remove(idNode);
      }
    }
    return all;
  }

  /** get the shared area of a certain type;
   *  since the result is a set of text values (String objects),
   *  sharedAreaValues() might return less items than
   *  sharedAreaNodes. duplicate texts are removed. */
  private HashSet sharedAreaValues(Type type) {
    HashSet set = new HashSet();

    Node lca = findLca(type);
    HashSet all = allTextDescNodes(lca);

    Iterator it = type.nodes.iterator();
    while (it.hasNext()) {
      Node node = (Node) it.next();
      HashSet nodeTextDesc = allTextDescNodes(node);
      Iterator nit = nodeTextDesc.iterator();
      while (nit.hasNext()) {
        Node textNode = (Node) nit.next();
        all.remove(textNode);
      }
    }

    /** transform the set of nodes to a set of node values (String objects) */
    Iterator nit = all.iterator();
    while (nit.hasNext()) {
      Node node = (Node) nit.next();
      String value = node.getNodeValue();
      set.add(value);
    }
    return set;
  }

  /** get the shared area of a certain type;
   *  since the result is a set of text values (String objects),
   *  sharedAreaValues() might return less items than
   *  sharedAreaNodes. duplicate texts are removed. */
  private HashSet sharedAreaValues2(Type type) {
    HashSet set = new HashSet();
    HashSet sharedNodes = sharedAreaNodes(type);

    /** transform the set of nodes to a set of node values (String objects) */
    Iterator nit = sharedNodes.iterator();
    while (nit.hasNext()) {
      Node node = (Node) nit.next();
      String value = node.getNodeValue();
      set.add(value);
    }
    return set;
  }

} // class Doc
