#!/usr/local/bin/perl -I/net/zeus/facstaff/cdyreson/public_html/cgi-bin/perl/pm

use strict;

my ($tnodes) = $ARGV[0];
my ($start) = $ARGV[1];
my ($rev) = $ARGV[2] || 0;
my %pubs = ();

#if ($start == 0) { $start = $tnodes * 5; }
#else { $start = int($tnodes * $start); }
$start = int($tnodes * $start);
$start = $tnodes - $start;

my $s = '';

# Generate books
my $namemod = int($tnodes / 7);
my $ch = '';
while ($tnodes) {
  my $name = $tnodes % $namemod;
  my $pub = $tnodes % 20;
  if ($tnodes <= $start) {$ch = '-';}
  $pubs{"pub$pub"} = {} unless defined $pubs{"pub$pub"};
  my $h = $pubs{"pub$pub"};
  $$h{"ne$name"} = [] unless defined $$h{"ne$name"};
  my $a = $$h{"ne$name"};
  push @$a, "ti$ch$tnodes";
  $tnodes--;
  }

foreach my $pub (keys %pubs) {
  $s .= "<publisher>$pub";
  my $authors = $pubs{$pub};
  foreach my $author (keys %$authors) {
    my $books = $$authors{$author};
    $s .= "<author>$author";
    foreach my $book (@$books) {
      $s .= "<book>";
      $s .= "<title>$book</title>";
      $s .= "</book>";
      }
    $s .= "</author>"; 
    }
  $s .= "</publisher>";
  }

print "<doc>$s</doc>\n";
