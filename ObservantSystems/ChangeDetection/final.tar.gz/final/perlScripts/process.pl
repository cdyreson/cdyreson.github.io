#!/usr/local/bin/perl -I/net/zeus/facstaff/cdyreson/public_html/cgi-bin/perl/pm

use strict;

my @lines = <>;
my @degrees = ();
my $previousDegree = -2;
my $total = join("", @lines);
my @tests = split(/curt/, $total);
my %totals = ();
shift @tests;
while (scalar @tests) {
  my $coordinates = shift @tests;
  my $times = shift @tests;
  $coordinates =~ /SIZE (\d+) DEGREE ([\d\.]+)/; 
  #print "size $1 degree $2\n";
  push @degrees, int($2 * 100) . "%"  unless $2 == $previousDegree;
  $previousDegree = $2;
  my $size = $1;
  $times =~ /Out of (\d+) nodes in document one, (\d+)/m; 
  #print "one matched $1 out of $2\n";
  $times =~ /Out of (\d+) nodes in document two, (\d+)/m; 
  #print "two matched $1 out of $2\n";
  $times =~ /total time elapsed: ([\d\.]+)seconds/m; 
  #print "time is $1\n";
  my $time = $1;
  $totals{$size} = [] unless defined $totals{$size};
  push @{$totals{$size}}, $time;
  }

print "Size, " . join(",", @degrees) . "\n";
foreach my $size (sort {$a <=> $b} keys %totals) {
  my $avg = join(",", @{$totals{$size}});
  my $sz = $size * 4;
  print "$sz, $avg\n";
  }
