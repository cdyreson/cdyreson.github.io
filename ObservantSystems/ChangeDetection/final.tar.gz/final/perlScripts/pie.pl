#!/usr/local/bin/perl -I/net/zeus/facstaff/cdyreson/public_html/cgi-bin/perl/pm

use strict;

my @lines = <>;
my @degrees = ();
my $previousDegree = -2;
my $total = join("", @lines);
my @tests = split(/curt/, $total);
my %totals = ();
shift @tests;
my $avgMatch = 0;
my $avgPhase1 = 0;
my $avgPhase2 = 0;
my $avgOther = 0;
my $avgNodeTerritory = 0;
my $avgParse = 0;
while (scalar @tests) {
  my $coordinates = shift @tests;
  my $times = shift @tests;
  $coordinates =~ /SIZE (\d+) DEGREE ([\d\.]+)/; 
  #print "size $1 degree $2\n";
  push @degrees, int($2 * 100) . "%"  unless $2 == $previousDegree;
  $previousDegree = $2;
  my $size = $1;
  $times =~ /parse: ([\d\.]+) seconds/m; 

  # Figure out parse times
  my $parse = $1;
  $' =~ /parse: ([\d\.]+) seconds/m; 
  $parse = $parse + $1;

  # Figure out phase1 times
  $times =~ /phase1: ([\d\.]+) seconds/m; 
  my $phase1 = $1;
  $' =~ /phase1: ([\d\.]+) seconds/m; 
  $phase1 = $phase1 + $1;

  # Figure out phase2 times
  $times =~ /phase2: ([\d\.]+) seconds/m; 
  my $phase2 = $1;
  $' =~ /phase2: ([\d\.]+) seconds/m; 
  $phase2 = $phase2 + $1;

  # Figure out nodeTerritory times 
  $times =~ /findNodeTerritory: ([\d\.]+) seconds/m; 
  my $findNodeTerritory = $1;
  $' =~ /findNodeTerritory: ([\d\.]+) seconds/m; 
  $findNodeTerritory += $1;

  $times =~ /Out of (\d+) nodes in document one, (\d+)/m; 
  #print "one matched $1 out of $2\n";
  $times =~ /Out of (\d+) nodes in document two, (\d+)/m; 
  #print "two matched $1 out of $2\n";
  $times =~ /total time elapsed: ([\d\.]+)seconds/m; 
  #print "time is $1\n";
  my $time = $1;
  $times =~ /time elapsed during mainProcess: ([\d\.]+) seconds/m; 
  my $idTime = $1;
  $totals{$size} = [] unless defined $totals{$size};

  my $matchTime = $time - $idTime;
  $avgMatch += $matchTime / $time;
  $avgPhase1 += $phase1 / $time;
  $avgPhase2 += $phase1 / $time;
  $avgParse += $parse / $time;
  $avgNodeTerritory += $findNodeTerritory / $time;
  $avgOther += ($time - ($matchTime + $phase1 + $phase2 + $parse + $findNodeTerritory))/ $time;

  push @{$totals{$size}}, $time;
  }

print "Size, " . join(",", @degrees) . "\n";
foreach my $size (sort {$a <=> $b} keys %totals) {
  my $avg = join(",", @{$totals{$size}});
  my $sz = $size * 4;
  print "$sz, $avg\n";
  }

$avgParse = int($avgParse * 2);
$avgPhase1 = int($avgPhase1 * 2);
$avgPhase2 = int($avgPhase2 * 2);
$avgMatch = int($avgMatch * 2);
$avgOther = int($avgOther * 2);
$avgNodeTerritory = int($avgNodeTerritory * 2);
print "$avgParse\n";
print "$avgPhase1\n";
print "$avgPhase2\n";
print "$avgNodeTerritory\n";
print "$avgMatch\n";
print "$avgOther\n";
