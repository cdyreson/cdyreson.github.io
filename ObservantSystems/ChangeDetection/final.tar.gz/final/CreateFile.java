import java.io.*;

public class CreateFile {

  public static void main(String[] argv) {
    if (argv.length < 2) {
      printUsage();
      System.exit(1);
    }
    // total number of authors
    int author = Integer.parseInt(argv[0]);
     // max number of books for each author, even distribution assumed
    int book = Integer.parseInt(argv[1]);

    // estimated numbers of total possible publishers and titles
    int publisher = (int)(Math.log(author*book));
    int title = (int)Math.round(author*book/2);

    try {
      OutputStream fout = new FileOutputStream("file.xml");
      OutputStream bout = new BufferedOutputStream(fout);
      OutputStreamWriter out
          = new OutputStreamWriter(bout, "8859_1");

      out.write("<?xml version=\"1.0\" ");
      out.write("encoding=\"ISO-8859-1\"?>\r\n");
      out.write("<bib>");
      for (int i = 1; i <= author; i++) {
        Integer inti = new Integer(i);
        out.write("<author>");

        out.write("<name>");
        out.write("name");
        out.write(inti.toString());
        out.write("</name>");

        double b = Math.random()*(double)(book-1)+1;
        int randombook = Math.round((float)b);
        for (int j = 1; j <= randombook; j++) {

          Integer intj = new Integer(j);
          out.write("<book>");

          double p = Math.random()*(double)publisher;
          Integer randompublisher = new Integer(Math.round((float)p));
          out.write("<publisher>");
          out.write("publisher");
          out.write(randompublisher.toString());
          out.write("</publisher>");

          double t = Math.random()*(double)title;
          Integer randomtitle = new Integer(Math.round((float)t));
          out.write("<title>");
          out.write("title");
          out.write(randomtitle.toString());
          out.write("</title>");

          out.write("</book>");
        }
        out.write("</author>");

      }
      out.write("</bib>");

      out.flush(); // Don't forget to flush!
      out.close();
    }
    catch (UnsupportedEncodingException e) {
      System.out.println(
          "This VM does not support the Latin-1 character set."
          );
    }
    catch (IOException e) {
      System.out.println(e.getMessage());
    }

  }

  /** Prints the usage. */
  private static void printUsage() {

    System.err.println("usage: first argument -- number of authors,");
    System.err.println("second argument -- max number of books for each author.");
    System.err.println();
  } // printUsage()

}
