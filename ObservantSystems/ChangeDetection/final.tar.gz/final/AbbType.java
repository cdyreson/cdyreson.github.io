/** Standard java packages for Containers */
import java.util.*;

/** Standard java packages for IO */
import java.io.*;

/** W3C packages for DOM trees */
import org.w3c.dom.*;

public class AbbType {

  public String name; // abbreviated name of Type: the current nodeName
  public HashSet nodes; // a set of Nodes of this type

  public AbbType(String t) {
    name = t;
    nodes = new HashSet();
  }

  public void addNode(Node node) {
    Object obj = (Object) node;
    nodes.add(obj);
  }

  public void printInfo() {
    fOut.println(" Info for abbreviated type '" + name + "' nodes:");
    fOut.println();
    fOut.println(" nodes: " + nodes);
    fOut.println();
  }

  /** Print writer. */
  private static PrintStream fOut = System.out;

} // class Type
