Run like

  java Transform xml/bib2.xml 'author#price#(publisher,title)' >result.xml

Generated document will be output to result.xml, but timing info will
be written to std err.


cheers, curtis
