(::pragma exist:output-size-limit 10000000 ::)
<bib>
 {
  for $b in /bib/book
  where $b/publisher = "1" and $b/@year > 1991
  return
    <book year="{ $b/@year }">
     { $b/title }
    </book>
 }
</bib> 
