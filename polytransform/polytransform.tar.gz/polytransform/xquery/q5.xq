(::pragma exist:output-size-limit 10000000 ::)
<books-with-prices>
  {
    for $b in //book,
        $a in //book
    where $b/title = $a/title
    return
        <book-with-prices>
            { $b/title }
            <price-bstore2>{ $a/price/text() }</price-bstore2>
            <price-bstore1>{ $b/price/text() }</price-bstore1>
        </book-with-prices>
  }
</books-with-prices>
