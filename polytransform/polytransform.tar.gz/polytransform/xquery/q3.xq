(::pragma exist:output-size-limit 10000000 ::)
<results>
{
    for $b in /bib/book
    return
        <result>
            { $b/title }
            { $b/author  }
        </result>
}
</results> 
