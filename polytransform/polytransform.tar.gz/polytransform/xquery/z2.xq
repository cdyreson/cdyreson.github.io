(::pragma exist:output-size-limit 10000000 ::)
<bib>
 {
  for $b in /bib/book
  return
      $b 
 }
</bib>
