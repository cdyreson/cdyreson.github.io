(::pragma exist:output-size-limit 10000000 ::)
<results>
  {
    for $b in /bib/book,
        $t in $b/title,
        $a in $b/author
    return
        <result>
            { $t }    
            { $a }
        </result>
  }
</results>
