/**
 * http://www.javaworld.com/javaworld/jw-08-1999/jw-08-cooltools_p.html#resources
 */

public class SmartIntArray {
  private int sp = 0; // "stack pointer" to keep track of position in the array
  private int[] array;
  private int growthSize;

  public SmartIntArray() {
    this(1024);
  }

  public SmartIntArray(int initialSize) {
    this(initialSize, (int) (initialSize / 4));
  }

  public SmartIntArray(int initialSize, int growthSize) {
    this.growthSize = growthSize;
    array = new int[initialSize];
  }

  public void add(int i) {
    if (sp >= array.length) { // time to grow!
      int[] tmpArray = new int[array.length + growthSize];
      System.arraycopy(array, 0, tmpArray, 0, array.length);
      array = tmpArray;
    }
    array[sp] = i;
    sp += 1;
  }

  public int[] toArray() {
    int[] trimmedArray = new int[sp];
    System.arraycopy(array, 0, trimmedArray, 0, trimmedArray.length);
    return trimmedArray;
  }

  public int size() {
    return sp;
  }
  /*
  public static String[] split(String token, String string) {
    SmartStringArray ssa = new SmartStringArray();

    int previousLoc = 0;
    int loc = string.indexOf(token, previousLoc);

    do {
      ssa.add(string.substring(previousLoc, loc));
      previousLoc = (loc + token.length());
      loc = string.indexOf(token, previousLoc);
    }
    while ( (loc != -1) && (previousLoc < string.length()));

    ssa.add(string.substring(previousLoc));

    return (ssa.toArray());
  }

  public static String join(String token, String[] strings) {
    StringBuffer sb = new StringBuffer();

    for (int x = 0; x < (strings.length - 1); x++) {
      sb.append(strings[x]);
      sb.append(token);
    }
    sb.append(strings[strings.length - 1]);

    return (sb.toString());
  }
*/
}
