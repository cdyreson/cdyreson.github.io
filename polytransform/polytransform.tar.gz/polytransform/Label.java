/*
 *
 */

import java.io.*;

/**
 * The Label class.
 */
public class Label {

  /** Print writer. */
  private static PrintStream fOut = System.out;

  /** A label is a String. */
  private String label;

  /** Initializes a newly created Label object so that it represents an empty label. */
  public Label() {
    label = "";
  }

  /** Constructs a new Label so that it represents the argument String. */
  public Label(String arg) {
    label = arg;
  }

  /** Get a String object of this Label. */
  public String getString() {
    return label;
  }

  public void print() {
    fOut.print(label);
  }
} // Label
