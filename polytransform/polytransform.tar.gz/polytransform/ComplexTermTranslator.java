/*
 *
 */

import java.io.*;
import java.util.*;

/**
 * The SignatureTranslator class.
 */
public class ComplexTermTranslator {

  /** Print writer. */
  private static PrintStream fOut = System.out;

  private int[] commaPositions;
  private int commaSize;
  private ComplexTerm complexTerm = new ComplexTerm();
/*
  public static void main(String argv[]) {
    //String cterm = "( title , author #name , price, pub)";
    //String cterm = "( title , author #(lname,fname,mname) , price, pub)";
    //String cterm = "( title , author #(lname, mname, fname,nickname) , price, pub)";
    //String cterm = "( title , author, price, pub)";
    //String cterm = "( title , (lname, mname, fname,nickname) , price, pub)";

    //Signature sig = SignatureTranslator.translate(cterm);
  }
*/
  public ComplexTermTranslator(String cterm) {
    cterm = cterm.trim();
    if ( (cterm.charAt(0) != '(') || (cterm.charAt(cterm.length()-1) != ')')) {
      System.err.println(
          "Error: a valid complex term starts with a '(' and ends with a ')'.");
      System.exit(1);
    }
    findCommasOuterMost(cterm);
    if (commaSize <= 0) {
      System.err.println("Error: a valid complex term contains at least two signatures.");
          System.exit(1);
        }
    else {
      //printCommas();
      int firstComma = commaPositions[0];
      String firstSig = cterm.substring(1, firstComma).trim();
      complexTerm.add(SignatureTranslator.translate(firstSig));
      //fOut.println("first sig in a complex term added in ComplexTermTranslator(): "+firstSig);

      if (commaSize > 1) {
        for (int i = 0; i < commaSize - 1; i++) {
          int startComma = commaPositions[i];
          int endComma = commaPositions[i + 1];
          String middleSig = cterm.substring(startComma + 1, endComma).trim();
          complexTerm.add(SignatureTranslator.translate(middleSig));
          //fOut.println("middle sig in a complex term added in ComplexTermTranslator(): "+middleSig);
        }
      } // if

      int lastComma = commaPositions[commaSize-1];
      String lastSig = cterm.substring(lastComma+1, cterm.length() - 1).trim();
      complexTerm.add(SignatureTranslator.translate(lastSig));
      //fOut.println("last sig in a complex term added in ComplexTermTranslator(): "+lastSig);
    } // else
  }

  public static boolean empty(String cterm) {
    if (cterm.trim().length() == 0) {
      return true;
    }
    else {
      return false;
    }
  }
/*
  public static boolean complexTerm(String cterm) {
    if (cterm.trim().startsWith("(")) {
      return true;
    }
    else {
      return false;
    }
  }
*/
  private void findCommasOuterMost(String cterm) {
    SmartIntArray smartArray = new SmartIntArray();
    //int index = 0;
    int count = 0;
    for (int i = 0; i < cterm.length(); i++) {
      if (cterm.charAt(i) == '(') {
        count++;
      }
      if (cterm.charAt(i) == ')') {
        count--;
      }
      if ( (cterm.charAt(i) == ',') && (count == 1)) {
        smartArray.add(i);
        //index++;
      }
    }
    commaSize = smartArray.size(); // extract the primitive array
    commaPositions = smartArray.toArray(); // extract the primitive array
  }

  public ComplexTerm getComplexTerm() {
    return complexTerm;
  }

  public void printCommas() {
    fOut.println("there are " + commaSize + " outermost commas at positions:");
    for (int i = 0; i < commaSize; i++) {
      fOut.println(commaPositions[i] + ", ");
    }
  }

} // ComplexTermTranslator
