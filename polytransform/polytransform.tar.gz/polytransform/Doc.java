/**
 * This program traverses a DOM tree and finds
 * (semantic) identifiers for all element nodes.
 */

/** Standard java packages for Collections */
import java.util.*;

/** Standard java packages for IO */
import java.io.*;

/** W3C packages for DOM trees */
import org.w3c.dom.*;

public class Doc {

  /** Document node */
  Document document;
  boolean typeIrregular = false;

  /** Print writer. */
  private static PrintStream fOut = System.out;
  private HashMap textValues = new HashMap();

  int nodeCounter = 0;
  int valueCounter = 0;

  public Doc() {
  }

  public Document getDoc() {
    return document;
    }

  /** Main processing method. */
  public void process(String file, HashMap typeToList, HashMap types, HashMap fullTypes) {

    Document doc = MyParser.parse(file);
    document = doc;

    // Set up the root type
    textValues.put("ROOT",new Integer(valueCounter++));
    types.put("ROOT", new ArrayList());
    fullTypes.put("ROOT", "ROOT");

    String value = traverse(doc, typeToList, types, fullTypes, "ROOT");
    SuperNode supNode = new SuperNode(doc.getDocumentElement(), 0, nodeCounter, value);
    ArrayList a = new ArrayList();
    a.add(supNode);
    typeToList.put("ROOT",a);
    
    if (typeIrregular) {
      System.err.println("Input is type irregular");
      System.exit(1);
      }
  } 

  private String traverse(Node node, HashMap typeToList, HashMap types, HashMap fullTypes, String prefix) {

    /** is there anything to do? */
    if (node == null) {
      return "";
    }

    short type = node.getNodeType();
    switch (type) {
      case Node.DOCUMENT_NODE: {

        nodeCounter = 0;
        String myName = node.getNodeName();
        types.put(myName, new ArrayList());
        Document document = (Document)node;
        return traverse(document.getDocumentElement(), typeToList, types, fullTypes, prefix);
      }

      case Node.ELEMENT_NODE: {
        int nodeNumber = nodeCounter++;

        // name of this node
        String nodeName = node.getNodeName();
        String fullNodeName = prefix + "." + nodeName;

        if (null == fullTypes.get(fullNodeName)) {
          fullTypes.put(fullNodeName, nodeName);
          if (null == types.get(nodeName)) {
            // get its parent node
            Node parent = node.getParentNode();

            // get parent's type
            String parentTypeName = parent.getNodeName();

            // compute this node's type
            ArrayList parentsType = (ArrayList)types.get(parentTypeName);
            ArrayList myType = (ArrayList)parentsType.clone();
            myType.add(nodeName);

            // add this type 
            types.put(nodeName, myType);
            }
          else {
            typeIrregular = true;
            }
          }

        // Initialize list if absent
        if (null == typeToList.get(nodeName)) {
          typeToList.put(nodeName, new ArrayList());
          }

        // This is the group value for the element
        String value = "";

        // Add the attributes to the group value
        Attr attrs[] = sortAttributes(node.getAttributes());
        for (int j = 0; j < attrs.length; j++) {
          Attr attr = attrs[j];

          // Process the attribute name
          String s = attr.getNodeName();
          Integer i = (Integer)textValues.get(s);
          if (i == null) {
            i = new Integer(valueCounter++);
            textValues.put(s, i);
          }
          value = value + "." + i.toString();

          // Process the attribute value
          s = attr.getNodeValue();
          i = (Integer)textValues.get(s);
          if (i == null) {
            i = new Integer(valueCounter++);
            textValues.put(s, i);
          }
          value = value + "." + i.toString();
          }

        boolean smallEnough = true;
        Node child = node.getFirstChild();
        while (child != null) {
          if (smallEnough) { 
            value = value + "." + traverse(child, typeToList, types, fullTypes, prefix + "." + nodeName);
            }
          else {
            traverse(child, typeToList, types, fullTypes, prefix + "." + nodeName);
            }
          smallEnough = value.length() > 150;
          child = child.getNextSibling();
        }

        SuperNode supNode = new SuperNode(node, nodeNumber, nodeCounter, value);
        ArrayList a = (ArrayList)typeToList.get(nodeName);
        a.add(supNode);
        //System.err.println(value);

        if (smallEnough) {return value;}
        else {return "zz" + nodeCounter;}
      }

      case Node.TEXT_NODE: {
        String s = node.getNodeValue();
        Integer i = (Integer)textValues.get(s);
        if (i == null) {
          i = new Integer(valueCounter++);
          textValues.put(s, i);
          }

        return i.toString();
        }
    }

    return "";

  } // traverse

    /** Returns a sorted list of attributes. */
    private static Attr[] sortAttributes(NamedNodeMap attrs) {

        int len = (attrs != null) ? attrs.getLength() : 0;
        Attr array[] = new Attr[len];
        for (int i = 0; i < len; i++) {
            array[i] = (Attr)attrs.item(i);
        }
        for (int i = 0; i < len - 1; i++) {
            String name = array[i].getNodeName();
            int index = i;
            for (int j = i + 1; j < len; j++) {
                String curName = array[j].getNodeName();
                if (curName.compareTo(name) < 0) {
                    name = curName;
                    index = j;
                }
            }
            if (index != i) {
                Attr temp = array[i];
                array[i] = array[index];
                array[index] = temp;
            }
        }

        return array;

    }

} // class Doc
