#!/usr/local/bin/perl -I/net/zeus/facstaff/cdyreson/public_html/cgi-bin/perl/pm

use strict;

my @sizes = (25000, 50000, 75000, 100000, 125000, 150000, 175000, 200000, 225000, 250000);
my @lines = <>;

my @grouped = ();
my @ungrouped = ();
print "Size Init Ungrouped Init2 Grouped\n";
while (scalar(@lines)) {
  my $phase1grouped = shift @lines;
  $phase1grouped =~ /Phase 1\s+: (\d+\.\d+)/; 
  $phase1grouped = $1;
  my $totalgrouped = shift @lines;
  $totalgrouped =~ /Time elapsed: (\d+\.\d+)/; 
  $totalgrouped = $1;
  my $phase1ungrouped = shift @lines;
  $phase1ungrouped =~ /Phase 1\s+: (\d+\.\d+)/; 
  $phase1ungrouped = $1;
  my $totalungrouped = shift @lines;
  $totalungrouped =~ /Time elapsed: (\d+\.\d+)/; 
  $totalungrouped = $1;
  print int(shift @sizes) * 6;
  print " $phase1ungrouped $totalungrouped";
  print " $phase1grouped $totalgrouped";
  print "\n";
  }

#print "Size, " . join(",", @degrees) . "\n";
