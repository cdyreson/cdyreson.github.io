#!/usr/local/bin/perl -I/net/zeus/facstaff/cdyreson/public_html/cgi-bin/perl/pm

use strict;


#my @degrees = (0, .25, .5, .75, 1);
my @degrees = (.5);
my @sizes = (2500, 5000, 7500, 10000, 12500, 15000, 17500, 20000, 22500, 25000);
#my @sizes = (250, 500, 750, 1000, 1250, 1500, 1750, 2000, 2250, 2500);
#my @sizes = (25, 50, 75, 100, 125, 150, 175, 200, 225, 250);
my $signature = 'publisher#title#author#(last,first)';
my $dir = 'docs';

foreach my $degree (@degrees) {
  foreach my $size (@sizes) {
    system "echo SIZE $size DEGREE $degree\n";
    system "java Transform $dir/bib.$size.$degree.xml '$signature'";
    system "echo NOGROUP\n";
    system "java TransformNoGroup $dir/bib.$size.$degree.xml '$signature'";
    }
  }
