#!/usr/local/bin/perl -I/net/zeus/facstaff/cdyreson/public_html/cgi-bin/perl/pm

use strict;

my %h = ();
my $inArticle = 0;
my $price = 0;
my $editor = 0;
my $total = 10000;
my $skip = 100;
print "<bib>\n";
while (<>) {
  my $line = $_;
  $price = $price % 100;
  $price++;
  $editor++;
  $editor = $editor % 10;
  if ($inArticle) {
    if ($line =~ '</inproceedings') { 
      $h{'price'} = $price;
      $inArticle = 0; 
      $skip--;
      next unless $skip < 0; 
      print "<book year=\"$h{'year'}\">\n";
      print "  <title>$h{'title'}</title>\n";
      if ($editor) {
        foreach my $pair (@{$h{'author'}}) {
          my ($last, $first) = @$pair;
          print "  <author><last>$last</last><first>$first</first></author>\n";
          }
        }
      else {
        unshift @{$h{'author'}}, ["noFirst", "noLast"] 
          unless defined($h{'author'});
        my ($pair) = (@{$h{'author'}});
        my ($last, $first) = @$pair;
        print "  <editor>\n";
        print "    <elast>$last</elast><efirst>$first</efirst>\n";
        print "    <affiliation>$h{'price'}</affiliation>\n";
        print " </editor>\n";
        }
      print "  <publisher>$h{'price'}</publisher>\n";
      print "  <price>$h{'price'}</price>\n";
      print "</book>\n";
      $total--;
      if ($total < 0) {
        print "</bib>\n";
        exit 1;
        }
      }
    else {
      $line =~ /<(\w+)>(.*)<\//;
      my $elem = $1;
      my $content = $2;
      #print "$elem $content\n";
      $content =~ s/&//g;
      $content =~ s/;//g;
      if ($elem =~ 'author') {
        my @names = split(" ", $content);
        my $last = pop @names || 'nolLast';
        my $first = shift @names || 'nofFirst';
        $h{'author'} = [] unless defined $h{'author'};
        unshift @{$h{'author'}}, [$first, $last];
        #print "$content first $first last $last \n";
        }
      elsif ($elem =~ 'journal') { 
        #$content =~ s/ //g;
        $h{'publisher'} = $content;
        #print "publisher $content\n";
        }
      elsif ($elem =~ 'title') { 
        #$content =~ s/ //g;
        $h{'title'} = $content;
        #print "title $content\n";
        }
      elsif ($elem =~ 'year') { 
        $content =~ s/ //g;
        $h{'year'} = $content;
        #print "year $content\n";
        }
      }
    }
  else {
    if ($line =~ '<inproceedings') { 
      %h = ();
      $inArticle = 1; 
      }
    }
  #print "i $inArticle\n";
  }
print "</bib>\n";
