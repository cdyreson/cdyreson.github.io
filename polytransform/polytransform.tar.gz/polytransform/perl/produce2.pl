#!/usr/local/bin/perl -I/net/zeus/facstaff/cdyreson/public_html/cgi-bin/perl/pm

use strict;

my ($tnodes) = $ARGV[0];
my ($start) = $ARGV[1];
my ($rev) = $ARGV[2] || 0;

#if ($start == 0) { $start = $tnodes * 5; }
#else { $start = int($tnodes * $start); }
$start = int($tnodes * $start);
$start = $tnodes - $start;

my $s = '';

# Generate books
my $namemod = int($tnodes / 7);
my $ch = '';
while ($tnodes) {
  my $name = $tnodes % $namemod;
  my $pub = $tnodes % 20;
  my $year = $tnodes % 50;
  if ($tnodes <= $start) {$ch = '-';}
  my $x .= "<book year=\"$year\">";
    $x .= "<title>ti$ch$tnodes</title>";
    $x .= "<author><last>ne$name</last><first>ge$name</first></author>";
    $x .= "<publisher>pub$pub</publisher>";
  $x .= "</book>";
  if ($rev) { $s = $x . $s; }
  else { $s = $s . $x; }
  $tnodes--;
  } 

print "<bib>$s</bib>\n";
