/** Standard java packages for Collections */
import java.util.*;

/** Standard java packages for IO */
import java.io.*;

/** W3C packages for DOM trees */
import org.w3c.dom.*;

/**
 * The Transform class.  The z-transform converts a document with a 
 * type-regular signature to a document that has a target signature.
 * The signature of the source is constructed.  The signature of the
 * target is given. Grouping is performed.
 **/
public class Transform {

  /** Doc of the new document. */
  private static Doc origDoc = new Doc();

  /** Document node of the new document. */
  private static Document newDoc;

  /** Maps a node in the new document back to a node in the original. */
  private static HashMap mapToOld = new HashMap();
  private static HashMap typeToList = new HashMap();
  private static HashMap types = new HashMap();
  private static HashMap fullTypes = new HashMap();

  private static HashSet oldLabelSet;

  public static void printUsage() {
    System.err.println(" java Transform 'signature' > result.xml");
    }

  public static void main(String argv[]) throws IOException {

    if (argv.length < 2) {
      printUsage();
      System.exit(1);
      }

    String inputFile = argv[0];
    String outputFile = "output.xml";
    String targetSig = argv[1];

    long start = System.currentTimeMillis();

    origDoc.process(inputFile, typeToList, types, fullTypes);

    Signature newSig = SignatureTranslator.translate(targetSig);

    ztransform(newSig, "ROOT");

    ArrayList top = (ArrayList)typeToList.get("ROOT");
    SuperNode sup = (SuperNode)top.get(0);

    Document oldDoc = (Document) origDoc.getDoc();
    long phase1TimeMillis = System.currentTimeMillis() - start;
    float phase1TimeSec = phase1TimeMillis / 1000F;
    Node newDoc = buildNewTree(sup,oldDoc.getDocumentElement());

    // print the result to result.xml
    System.out.print(newDoc);

    long mainProcessTimeMillis = System.currentTimeMillis() - start;
    float mainProcessTimeSec = mainProcessTimeMillis / 1000F;
    System.err.println(" Phase 1     : " + phase1TimeSec + " seconds");
    System.err.println(" Time elapsed: " + mainProcessTimeSec + " seconds");
    System.out.close(); // Remember this!
    }

  private static Node buildNewTree(SuperNode sup, Node root) {
    // Let's do this node
    //System.out.println("Node is " + root + sup);
    Node node = sup.node();
    // First, clone the node
    Node newNode = node.cloneNode(false);

    // Next, group all of the children
    ArrayList children = sup.children();
    ArrayList newChildren = new ArrayList();
    HashMap groupHash = new HashMap();
    for (int i = 0; i < children.size(); i++) {
      SuperNode child = (SuperNode) children.get(i);
      String groupValue = child.groupValue();
      SuperNode supNode = (SuperNode)groupHash.get(groupValue);
      if (supNode == null) {
        // Create group
        groupHash.put(groupValue,child);
        newChildren.add(child);
        }
      else {
        // Add to group by extending children of SuperNode
        supNode.extendChildren(child);
        }
      }
   
    // Next, figure out the new form of each child
    HashMap childHash = new HashMap();
    for (int i = 0; i < newChildren.size(); i++) {
      SuperNode child = (SuperNode) newChildren.get(i);
      childHash.put(child.node(),buildNewTree(child,child.node()));
      }
 
    // Remove children that are not in the SuperNode
    // Also, replace children that are in the SuperNode
    Node child = node.getFirstChild();
    while (child != null) {
      Node nextChild = child.getNextSibling();
      short type = child.getNodeType();
      if (type == Node.ELEMENT_NODE) {
        Node n = (Node)childHash.get(child);
        if (n != null) {
          childHash.remove(child);
          //newNode.replaceChild(n,child);
          newNode.appendChild(n);
          }
        else {
          // Do nothing, element type is not in the output
          //if (types.get(child.getNodeName()) != null) {
            //newNode.removeChild(child);
          //  }
          //newNode.appendChild(child);
          }
         }
      else {
        newNode.appendChild(child);
        }
      child = nextChild;
      }

    // Process the remaining children
    Set s = childHash.keySet();
    Iterator iterate = s.iterator();
    while (iterate.hasNext()) {
      Node n = (Node)iterate.next();
      newNode.appendChild((Node)childHash.get(n));
      }

    return newNode;

    }

  private static void ztransform(Signature sig, String parentType) {

    // Get parent node list
    ArrayList parentNodes = (ArrayList)typeToList.get(parentType);
    if (parentNodes == null) {
      System.err.println("No nodes of this type " + parentType);
      System.exit(1);
      }

    // First let's process all of the simple terms in the signature
    ArrayList labels = sig.labels; 
    if (labels == null) return;
    for (int i = 0; i < labels.size(); i++) {

      // Get the next label
      Label label = (Label) labels.get(i);
      String nodeType = label.getString();
      //System.err.println(nodeType + " working " + parentType);

      // Get nodes of this type
      ArrayList nodes = (ArrayList)typeToList.get(nodeType);
      if (nodes == null) {
        System.err.println("No nodes of this type " + nodeType);
        System.exit(1);
        }

      // Figure out merging by looking at prefixes
      ArrayList parentLabels = (ArrayList)types.get(parentType);
      ArrayList nodeLabels = (ArrayList)types.get(nodeType);
      int last = 0;
      while (last < parentLabels.size() && last < nodeLabels.size()) {
        String s = (String)parentLabels.get(last);
        String s2 = (String)nodeLabels.get(last);
        if (!s.equals(s2)) break;
        last++;
        }

      // Do we have a ancestor/descendent?
      if (last >= parentLabels.size()) {
        //System.err.println(parentType + " is an ancestor of " + nodeType);
        mergeAbove(parentNodes,nodes);
        }

      // Do we have a descendent/ancestor?
      else if (last >= nodeLabels.size()) {
        //System.err.println(parentType + " is a desc of " + nodeType);
        mergeBelow(parentNodes,nodes);
        }

      // We have an LCA
      else {
        //System.err.println(parentType + " is a sibling of " + nodeType);
        String lcaType = (String)parentLabels.get(last-1);
        //System.err.println(lcaType + " is LCA");

        // We merge using the LCA
        ArrayList lcaNodes = (ArrayList)typeToList.get(lcaType);
        mergeLCA(parentNodes,nodes,lcaNodes);
        }

      // Done with this one, move to the next term
      parentType = nodeType;
      parentNodes = nodes;
      }

    ComplexTerm term = sig.lastTerm; 
    //System.err.println("Term is " + term.getString());
    if (term == null) {
      //System.err.println("No last term");
      return;
      }

    ArrayList sigs = term.subSignatures;
    for (int i = 0; i < sigs.size(); i++) {
      //System.err.println("Doing a signature");
      ztransform((Signature)sigs.get(i),parentType);
      }

    } // ztransform 

 private static void mergeAbove(ArrayList parents, ArrayList nodes) {

    // Initialize the current node counter
    int j = 0;

    // Iterate through the parents
    for (int i = 0; i < parents.size(); i++) {
      //System.err.println("Trying parent");
      SuperNode parent =  (SuperNode)parents.get(i);
      ArrayList children = parent.children();
      int current = parent.nodeNumber();
      int max = parent.maxDescendent();
      HashSet groups = new HashSet();

      // Do all the children for this parent
      while (j < nodes.size()) {
        //System.err.println("Trying child");
        // Get the first node
        SuperNode child = (SuperNode)nodes.get(j);
        if (child.nodeNumber() > max) break;

        // Is this child a descendant?
        if (child.nodeNumber() >= current) {
          children.add(child);
          }

        // Skip if this has already been grouped
        //if (groups.contains(child.groupValue()) continue;

        j++; 
        }
      }

    }

 private static void mergeBelow(ArrayList nodes, ArrayList parents) {

    // Initialize the current node counter
    int j = 0;
    int previousParent = 0;

    // Iterate through the nodes
    for (int i = 0; i < nodes.size(); i++) {
      //System.err.println("Trying node");
      SuperNode node = (SuperNode)nodes.get(i);
      ArrayList children = node.children();
      int current = node.nodeNumber();
      //HashSet groups = new HashSet();
    
      j = previousParent;
      // Do all the parents for this node
      while (j < parents.size()) {
        // Get the first parent
        SuperNode parent = (SuperNode)parents.get(j);

        //System.err.println("Trying parent" + parent.nodeNumber() + " " + current);
        // Gone too far?
        if (parent.nodeNumber() > current) break;

        // Is this parent an ancestor?
        if (parent.nodeNumber() <= current &&
            parent.maxDescendent() >= current) {
          //System.err.println("Got one");
          children.add(parent);
          }
        else {previousParent = j;}

        // Skip if this has already been grouped
        //if (groups.contains(child.groupValue()) continue;

        j++;
        }
      }

    }

private static void mergeLCA(ArrayList parents, ArrayList nodes, ArrayList lcas) {
    // Initialize the current node counters
    int parentCounter = 0;
    int nodeCounter = 0;

    // Iterate through the lcas
    for (int i = 0; i < lcas.size(); i++) {
      //System.err.println("Trying lca");
      SuperNode lca =  (SuperNode)lcas.get(i);
      ArrayList parentList = new ArrayList();
      ArrayList nodeList = new ArrayList();
      int current = lca.nodeNumber();
      int max = lca.maxDescendent();

      // Do all the parent children for this lca
      while (parentCounter < parents.size()) {
        //System.err.println("Trying parent");
        // Get the first node
        SuperNode parent = (SuperNode)parents.get(parentCounter);
        if (parent.nodeNumber() > max) break;

        // Is this parent a descendant?
        if (parent.nodeNumber() >= current) {
          parentList.add(parent);
          }

        // Skip if this has already been grouped
        //if (groups.contains(child.groupValue()) continue;

        parentCounter++;
        }
 
      // No parents?
      if (parents.size() == 0) continue;

      // Do all the node children for this lca
      while (nodeCounter < nodes.size()) {
        //System.err.println("Trying node");
        // Get the first node
        SuperNode node = (SuperNode)nodes.get(nodeCounter);
        if (node.nodeNumber() > max) break;

        // Is this parent a descendant?
        if (node.nodeNumber() >= current) {
          nodeList.add(node);
          }

        // Skip if this has already been grouped
        //if (groups.contains(child.groupValue()) continue;

        nodeCounter++;
        }

      // Add all the children below each parent
      for (int k = 0; k < parentList.size(); k++) {
        SuperNode parent = (SuperNode)parentList.get(k);
        ArrayList children = parent.children();
        for (int j = 0; j < nodeList.size(); j++) {
          SuperNode node = (SuperNode)nodeList.get(j);
          children.add(node);
          }
        }

      }

    }

} // class
