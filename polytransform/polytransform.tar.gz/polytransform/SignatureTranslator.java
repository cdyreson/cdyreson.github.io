/*
 *
 */

import java.io.*;
import java.util.*;

/**
 * The SignatureTranslator class.
 */
public class SignatureTranslator {

  /** Print writer. */
  private static PrintStream fOut = System.out;

  public static void main(String argv[]) {

    String cterm =
        "bib#book#( title , author #name#(lname, mname, fname,nickname) , price, pub)";
    //String cterm = "( title , (lname, mname, fname,nickname) , price, pub)";
    translate(cterm).print();
  }

  public static Signature translate(String signature) {
    //fOut.println(signature);
    String sigParameter = signature;
    Signature result = new Signature();
    String prefix = prefix(signature);
    //fOut.println("start processing signature: " + signature);
    while (!empty(prefix)) {
      if (!complexTerm(prefix)) {
        //fOut.println("a simple term");
        result.add(new Label(prefix));
        //fOut.println("a label added in SignatureTranslator.translate: " + prefix);
        signature = suffix(signature);
        prefix = prefix(signature);
      }
      else { // prefix is a complex term
        //fOut.println("a complex term");
        ComplexTermTranslator cterm = new ComplexTermTranslator(prefix);
        result.add(cterm.getComplexTerm());
        //fOut.println("a ccomplex term added in SignatureTranslator.translate: " + prefix);
        break;
      } // else
    }
    //fOut.("finished processing signature: " + sigParameter);
    return result;
  }

  public static boolean empty(String signature) {
    if (signature.trim().length() == 0) {
      return true;
    }
    else {
      return false;
    }
  }

  public static boolean complexTerm(String signature) {
    if (signature.trim().startsWith("(")) {
      return true;
    }
    else {
      return false;
    }
  }

  public static String prefix(String signature) {
    String prefix = new String(signature);
    if (!complexTerm(signature)) {
      int firstPound = signature.indexOf('#');
      if (firstPound > -1) {
        prefix = prefix.substring(0, firstPound).trim();
      }
    }
    //fOut.println("the prefix is: " + prefix);
    return prefix;
  } // prefix

  public static String suffix(String signature) {
    String suffix = new String();
    if (empty(signature)) {
      return suffix;
    }
    else if (!complexTerm(signature)) {
      int firstPound = signature.indexOf('#');
      if (firstPound > -1) {
        suffix = signature.substring(firstPound).replaceFirst("#", " ").trim();
      }
    }
    //fOut.println("the suffix is: " + suffix);
    return suffix;
  } // suffix

} // SignatureTranslator
