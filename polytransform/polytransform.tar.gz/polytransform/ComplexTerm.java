/*
 *
 */

import java.io.*;
import java.util.*;

/**
 * The ComplexTerm class.
 */
public class ComplexTerm {

  /** Print writer. */
  private static PrintStream fOut = System.out;

  /** This field is a ArrayList of Signature objects. */
  ArrayList subSignatures;

  /** Initializes a newly created ComplexTerm object so that it represents an empty ComplexTerm. */
  public ComplexTerm() {
    subSignatures = new ArrayList();
  }

  /** Constructs a new ComplexTerm so that it represents an ArrayList of Signature objects. */
  public ComplexTerm(ArrayList arg) {
    subSignatures = arg;
  }

  public void add(Signature sig) {
    subSignatures.add(sig);
  } // add

  public void print() {
    fOut.println(this.getString());
  }

  public String getString() {
    String result = new String();
    result = result.concat("(");
    for (int i = 0; i < subSignatures.size() - 1; i++) {
      Signature subSig = (Signature) subSignatures.get(i);
      result = result.concat(subSig.getString());
      result = result.concat(",");
    }
    if (subSignatures.size() > 0) {
      Signature subSig = (Signature) subSignatures.get(subSignatures.size() - 1);
      result = result.concat(subSig.getString());
      }
    result = result.concat(")");
    return result;
  } // print

  public int size() {
    return subSignatures.size();
  } // size

  /** Get a ArrayList object of this ComplexTerm. */
  public ArrayList valueOf() {
    return subSignatures;
  } // valueOf

} // ComplexTerm
