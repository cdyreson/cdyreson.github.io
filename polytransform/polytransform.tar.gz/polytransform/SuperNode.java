/**
 * This class implements the parts of a node record
 */

/** Standard java packages for Collections */
import java.util.*;

/** Standard java packages for IO */
import java.io.*;

/** W3C packages for DOM trees */
import org.w3c.dom.*;

public class SuperNode {

  private ArrayList children;
  private int nodeNumber;
  private int maxDescendent;
  private String groupValue;
  private Node node;

  public SuperNode(Node node, int nodeNumber, int maxDescendent, String groupValue) {
    this.node = node;
    this.nodeNumber = nodeNumber;
    this.maxDescendent = maxDescendent;
    this.groupValue = groupValue;
    this.children = new ArrayList();
  }

  public int nodeNumber() { return nodeNumber; }
  public int maxDescendent() { return maxDescendent; }
  public String groupValue() { return groupValue; }
  public ArrayList children() { return children; }
  public ArrayList newChildren() { return children; }
  public Node node() { return node; }
  public void extendChildren(SuperNode n) { 
     children.addAll(n.children());
     }

} // class SuperNode
