/*
 *
 */

import java.io.*;
import java.util.*;

/**
 * The Signature class.
 */
public class Signature {

  /** Print writer. */
  private static PrintStream fOut = System.out;

  /** String representation. */
  static String sig = new String();

  /** Leading simple terms, which are all labels, in this signature. */
  ArrayList labels = new ArrayList();

  /** The last term, which is acomplex term, in this signature. */
  ComplexTerm lastTerm = new ComplexTerm();

  /** Constructs an empty Signature. */
  public Signature() {
  }

  /* Constructs a Signature with a given String.
     public Signature(String str) {
    sig = str;
     }
   */

  /** Constructs a Signature with a given Label (a simple term). */
  public Signature(Label label) {
    labels.add(label);
    sig = label.getString();
  }

  /** Constructs a Signature with a given ArrayList of Labels (simple terms). */
  public Signature(ArrayList arrayOfLabels) {
    labels = arrayOfLabels;
    for (int i = 0; i < labels.size() - 1; i++) {
      Label label = (Label) labels.get(i);
      sig.concat(label.getString());
      sig.concat("#");
    }
    Label label = (Label) labels.get(labels.size() - 1);
    sig.concat(label.getString());
  }

  /** Constructs a Signature with a given complex term. */
  public Signature(ComplexTerm term) {
    lastTerm = term;
    sig.concat(lastTerm.getString());
  }

  /** Constructs a Signature with a given array of simple terms and a complex term. */
  public Signature(ArrayList arrayOfLabels, ComplexTerm term) {
    labels = arrayOfLabels;
    lastTerm = term;
    if ( (labels.size() > 0) && (lastTerm.size() > 0)) { // has both simple and complex terms
      for (int i = 0; i < labels.size(); i++) {
        Label label = (Label) labels.get(i);
        sig.concat(label.getString());
        sig.concat("#");
      }
      sig.concat(lastTerm.getString());
    }
  }

  /** Add a label (a simple term). */
  public void add(Label label) {
    labels.add(label);
    //System.out.println("Adding " + label);
  } // add a label

  /** Add a complex term. */
  public void add(ComplexTerm cterm) {
    if (lastTerm.size() == 0) {
      lastTerm = cterm;
    }
    else {
      System.err.println(
          "Cannot add complex term, this signature already has one.");
      System.exit(1);
    }
  } // add a complex term

  /** Returns whether this signature is empty. */
  public boolean empty() {
    if ( (lastTerm.size() == 0) && (labels.size() == 0)) {
      return true;
    }
    else {
      return false;
    }
  } // empty

  /** Print this signature. */
  public void print() {
    fOut.println(this.getString());
  } // print

  /** Returns a String representing this signature. */
  public String getString() {
    //return sig;
    String result = new String();
    if ( (labels.size() > 0) && (lastTerm.size() > 0)) { // has both simple and complex terms
      for (int i = 0; i < labels.size(); i++) {
        Label label = (Label) labels.get(i);
        result = result.concat(label.getString());
        result = result.concat("#");
      }
      result = result.concat(lastTerm.getString());
      //fOut.println("signature is: " + result);
    } // if
    else if (labels.size() > 0) { // has simple terms only
      for (int i = 0; i < labels.size() - 1; i++) {
        Label label = (Label) labels.get(i);
        result = result.concat(label.getString());
        result = result.concat("#");
      }
      Label label = (Label) labels.get(labels.size() - 1);
      result = result.concat(label.getString());
      //fOut.println("signature is: " + result);
    } // else if
    else if (lastTerm.size() > 0) { // has a complex term only
      result = result.concat(lastTerm.getString());
      //fOut.println("signature is: " + result);
    } // else if
    sig = result;
    return result;

  } // getString

  /** Returns a boolean whether this signature is a complex term. */
  public boolean complexTerm() {
    if ( (labels.size() == 0) && (lastTerm.size() > 0)) {
      return true;
    }
    else {
      return false;
    }
  }

  /** Returns the prefix of this signature as a String. */
  public String prefixString() {
    if (labels.size() > 0) {
      return ( (Label) labels.get(0)).getString();
    } // if
    else if (lastTerm.size() > 0) {
      return lastTerm.getString();
    }
    else {
      fOut.println("This signature is empty, thus the prefix is empty as well.");
      return new String();
    }
  } // prefixString()

  /** Returns the prefix of this signature as a Signature. */
  public Signature prefix() {
    if (labels.size() > 0) {
      Label prefix = (Label) labels.get(0);
      return new Signature(prefix);
    } // if
    else if (lastTerm.size() > 0) {
      return new Signature(lastTerm);
    }
    else {
      fOut.println("This signature is empty, thus the prefix is empty as well.");
      return new Signature(lastTerm);
    }
  } // prefix()

  /** Returns the suffix of this signature as a Signature. */
  public Signature suffix() {
    if (labels.size() > 0) {
      ArrayList list = new ArrayList();
      for (int i = 1; i < labels.size(); i++) {
        list.add(labels.get(i));
      }
      Signature suffix = new Signature(list, lastTerm);
      //fOut.println("the suffix is: " + suffix);
      return suffix;
    } // if
    else {
      fOut.println(
          "This signature has no simple term, thus the suffix is empty.");
      return new Signature();
    }
  } // suffix()

  /** Returns the complex term of this signature (a ComplexTerm object). */
  public ComplexTerm getComplexTerm() {
    return lastTerm;
  }

  /** Returns a HashSet of String objects representing all labels in this signature. */
  public HashSet getLabelSet() {
    HashSet result = new HashSet();
    for (int i = 0; i < labels.size(); i++) {
      Label label = (Label) labels.get(i);
      result.add(label.getString());
    }
    if (lastTerm.size() > 0) {
      for (int i = 0; i < lastTerm.subSignatures.size(); i++) {
        Signature subsig = (Signature) lastTerm.subSignatures.get(i);
        HashSet subsigSet = subsig.getLabelSet();
        Iterator it = subsigSet.iterator();
        while (it.hasNext()) {
          String str = (String) it.next();
          result.add(str);
        }
      }
    }
    return result;
  }
} // Signature
