package w3c.tools.dbm ;

public class File {
  public String name;
  public File(String name) {
    this.name = name;
    }
}
