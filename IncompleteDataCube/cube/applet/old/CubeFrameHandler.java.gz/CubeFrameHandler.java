package cube.gui;

import java.awt.*;
import cube.globals.*;

public class CubeFrameHandler extends CubeFrameLayout {

  /**
   * Create a new handler
   **/
  public CubeFrameHandler(String title) {
    super(title);
  }

  /**
   * Handle an event
   **/
  public boolean handleEvent(Event event) {
    switch(event.id) {
      case Event.ACTION_EVENT:

	//  Handle double click on item  
        for (int i = 0; i < Constants.dimensions; i++) {
          if (event.target == Main.unitList[i]) Action.selectUnit(i);
          }

        // handle menu items   
        if (event.target instanceof MenuItem) {
          if (((String)event.arg).equals("Quit!")) {
            System.out.println("Quiting");
            System.exit(0);
            }

          if (((String)event.arg).equals("Query")) {
            System.out.println("Query selected");
            }
          if (((String)event.arg).equals ("ReadSpec")) {
            System.out.println("ReadSpec selected");
            }

          if (((String)event.arg).equals ("Help")) {
            Action.helpBox();
            }

          if (((String)event.arg).equals ("About")) {
            Action.aboutBox();
            }
          }

        // handle buttons
        if (event.target == execButton) {
          Action.runQuery();
          }
        for (int i = 0; i < Constants.dimensions; i++) {
          if (event.target == redoButton[i]) Action.redoMeasuresForUnits(i);
          }

      break;

        //  handle the list boxes (Single click)  

      case Event.LIST_SELECT:
        for (int i = 0; i < Constants.dimensions; i++) {
          if (event.target == Main.measureList[i]) Action.selectMeasure(i);
          }
         
        //////////////////////////////
        //    Unit lists            //
        //////////////////////////////

        for (int i = 0; i < Constants.dimensions; i++) {
          if (event.target == Main.unitList[i]) Action.updateUnit(i);
          }

      break;

      case Event.LIST_DESELECT:
        return false;

      case Event.WINDOW_DESTROY:
        System.out.println("Bye...");
        System.exit(0);

      case Event.WINDOW_ICONIFY:
      case Event.WINDOW_DEICONIFY:
      case Event.WINDOW_MOVED:
        return false;

      case Event.MOUSE_DOWN:
      case Event.MOUSE_UP:
      case Event.MOUSE_DRAG:
        return false;

      case Event.KEY_PRESS:
      case Event.KEY_ACTION:
      case Event.KEY_RELEASE:
      case Event.KEY_ACTION_RELEASE:
        return false;

      case Event.GOT_FOCUS:
      case Event.LOST_FOCUS:
      case Event.MOUSE_ENTER:
      case Event.MOUSE_EXIT:
      case Event.MOUSE_MOVE:
        return false;

      default:
        System.out.println("Missed one !!");
      break;
    }
    return true;
  }

}
