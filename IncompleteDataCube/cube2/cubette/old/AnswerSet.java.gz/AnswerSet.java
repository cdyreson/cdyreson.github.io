package cube.cubette;

import java.io.*;
import java.util.*;
import cube.tools.*;
import cube.database.*;
import cube.persistent.*;

public class AnswerSet {
  private Hashtable h;

  public AnswerSet() {
    h = new Hashtable();
    }

  public void add(int[] key, int value) {
    h.put(key, new Integer(value));
    }
}
