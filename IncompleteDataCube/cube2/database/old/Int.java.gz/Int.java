package cube.database;

import java.lang.*;
import java.util.*;

public class Int {
  public int id;
  public static final int byteSize = 4;

  /** 
  * Construct an Int from a byte array 
  */
  public Int(byte[] b) {
    id = (b[3] & 0x000000FF) +
         ((b[2] & 0x000000FF) << 8) +
         ((b[1] & 0x000000FF) << 16) +
         ((b[0] & 0x000000FF) << 24);
    } 

  /** 
  * The initial value of the Int is taken from the integer array
  */
  public Int(int[] id) {
    this.id = id[0];
    } 

  /** 
  * The initial value of the Int is taken from the integer
  */
  public Int(int id) {
    this.id = id;
    } 

  /** 
  * Initialise the Int to zero
  */
  public Int() {
    this.id = 0;
    } 

  /** 
  * Return an image of the id as a string
  */
  public String image() {
    return new String("" + this.id);
    } 

  /** 
  * Return a duplicate of the object 
  */
  public Int cloneMe() {
    return new Int(this.id);
    } 

  // We should kill this as it shouldn't be used!
  //public int intValue() {
    //return this.id;
    //} 

  /** 
  * Increment an Int (this is for counters)
  */
  public void add(Int other) {
    this.id += other.id;
    } 

  /** 
  * Increment an Int (this is for counters)
  */
  public void increment() {
    this.id++;
    } 

  /** 
  * Convert to a byte array 
  */
  public byte[] ToByteArray() {
    byte[] b = new byte[byteSize];
    b[3] = (byte) (id >>> 0);
    b[2] = (byte) (id >>> 8);
    b[1] = (byte) (id >>> 16);
    b[0] = (byte) (id >>> 24);
    return b;
    }

}
